package net.jpmchase.gti.automation.ibroker.storage.client.rest.transformer;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowTokenStatustRequest;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowTokenStatusResponse;
import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.WorkflowTokenStatusJSONResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class WorkflowTokenStatusRestPayloadTransformer  extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowTokenStatusRestPayloadTransformer.class);
  private static final String PORT_DELIMITER = ":";
  
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {
	WorkflowTokenStatusJSONResponse workflowTokenStatusJSONResponse = null;
	String[] returnValues = new String[] {new String(), new String()};
	Object src = message.getPayload();
	
	logger.info("PayloadTransformer received payload src=" + src);
		
	String vcoUser = message.getInvocationProperty("app.vco.user");
	String securityURL = message.getInvocationProperty("app.security.url.v3");
	String scriptWithDir = message.getInvocationProperty("httpConnectorScript");
	
	String vcoPassword = net.jpmchase.gti.automation.ibroker.storage.EndpointUserCacheCollection.getPassword(vcoUser) ;	
	if (vcoPassword == null || vcoUser.equals(vcoPassword))
	{
	  vcoPassword = "1Crazyd2"; //_getEndpointPassword(securityURL, vcoUser);
	  net.jpmchase.gti.automation.ibroker.storage.EndpointUserCacheCollection.cacheUser(vcoUser, vcoPassword);
	}
		
	String credential = vcoUser + ":" + vcoPassword;
	String basicAuth = "" + new String(Base64.encodeBase64(credential.getBytes()));
	
	if (src instanceof WorkflowTokenStatusResponse)
	{
	  
	  WorkflowTokenStatusResponse response  = (WorkflowTokenStatusResponse)src;
	  WorkflowTokenStatustRequest request = response.getRequest();

	  String vcoHost[] = request.getVCOFQDN().split(PORT_DELIMITER);
	  String queryURI = "/vco/api/workflows/ba769b0d-7e8a-46e4-ad38-85647b30ff22/executions/" + request.getWorkflowTokenIds().get(0);
	  
	  //String queryURI = "/vco/api/workflows/{workflowid}/executions/" + request.getWorkflowTokenIds().get(0);
	  String payload = "''";	
	  String commandWithArguments = scriptWithDir + " " + basicAuth + " " 
	  				+ vcoHost[0] + " " + vcoHost[1] + " " + "GET" + " " + queryURI + " " + payload;
			
	  logger.info("transformMessage(): running commandWithArguments=" + commandWithArguments);
	  try{
	  Runtime runtime = Runtime.getRuntime();
	  Process process = runtime.exec(commandWithArguments);
	  InputStream is = process.getInputStream();
	  InputStreamReader isr = new InputStreamReader(is);
	  BufferedReader br = new BufferedReader(isr);
	  
      logger.info("transformMessage(): reading output");		
	  String line;
	  int i=0;
	  while ((line = br.readLine()) != null) {
		  returnValues[i] = line;
		  i++;
		  logger.info(line);
	  }

	  logger.info("transformMessage(): setting return values:" + returnValues[1]);		       
	  message.setInvocationProperty("vcoStatus", returnValues[0]);
	  message.setInvocationProperty("vcoResponse", returnValues[1]);
	  
	  workflowTokenStatusJSONResponse = new WorkflowTokenStatusJSONResponse();
	  ObjectMapper mapper = new ObjectMapper();
	  workflowTokenStatusJSONResponse = mapper.readValue(returnValues[1], WorkflowTokenStatusJSONResponse.class);
		
	  logger.info("JSON parsing is done");
		
	  }catch(Exception e){
		 logger.error(e);
	  }
	}
	
	return workflowTokenStatusJSONResponse;	
  }    
}

