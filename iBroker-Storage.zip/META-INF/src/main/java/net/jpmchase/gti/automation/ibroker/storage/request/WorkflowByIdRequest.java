package net.jpmchase.gti.automation.ibroker.storage.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="workflowByIdRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowByIdRequest")
public class WorkflowByIdRequest extends WorkflowRequest
{
  @XmlElement(name="workflowId", required=false)  
  private String workflowId;

public String getWorkflowId() {
	return workflowId;
}

public void setWorkflowId(String workflowId) {
	this.workflowId = workflowId;
}
  
  

}

