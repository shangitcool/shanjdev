package net.jpmchase.gti.automation.ibroker.storage.exception;

import org.apache.log4j.Logger;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowTokenResultResponse;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class WorkflowTokenResultServiceException extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowTokenResultServiceException.class);
			 
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)  
	throws TransformerException 
  {		  
	WorkflowTokenResultResponse response = new WorkflowTokenResultResponse();	 
	Object object = message.getPayload();
		
	logger.error("An error occurred:" + object);
	String errorCode = message.getInvocationProperty("errorCode");
		
	String[] errors = errorCode.split(",");
	Status status = new Status();
	status.setStatusCode(errors[0]);
	status.setStatusDescription(errors[1] + "," + ((Exception)object).toString());	
		
	response.setStatus(status);		
	return response;
	  
  }  
}

