package net.jpmchase.gti.automation.ibroker.storage.transformer;

import net.jpmchase.gti.automation.ibroker.storage.response.PingResponse;

import org.apache.log4j.Logger;

import org.mule.transformer.AbstractMessageTransformer;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;

public class PingMessageTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(PingMessageTransformer.class);
 
  public PingResponse transformMessage(MuleMessage message, String outputEncoding)
  	throws TransformerException
  {
	PingResponse pingResponse = (PingResponse)message.getPayload();
	
	logger.debug("Executing ping message transformer...");
	String appVersion = message.getInvocationProperty("app.version");
	
	logger.info("app version=" + appVersion);
	pingResponse.setVersion(appVersion);	
	  
	return pingResponse;
  }
}
