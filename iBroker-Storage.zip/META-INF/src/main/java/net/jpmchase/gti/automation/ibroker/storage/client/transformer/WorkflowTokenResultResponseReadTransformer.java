package net.jpmchase.gti.automation.ibroker.storage.client.transformer;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.WorkflowTokenAttribute;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowTokenResultResponse;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

public class WorkflowTokenResultResponseReadTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowTokenResultResponseReadTransformer.class);
	
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {
	Object result = null;
	boolean checkSuccessReturnCode = false;
	boolean checkRetryReturnCode = false;
	WorkflowTokenResultResponse response  = new WorkflowTokenResultResponse();
	ArrayList<WorkflowTokenAttribute> workflowTokenAttributes = new ArrayList<WorkflowTokenAttribute>();
	Object src = message.getPayload();

	logger.info("WorkflowTokenResultResponseReadTransformer received payload src=" + src);

	String successCode = message.getInvocationProperty("reserved.success");
	String retryCode = message.getInvocationProperty("reserved.retry");
	String errorCode = message.getInvocationProperty("reserved.failed");	
	String noResultCode = message.getInvocationProperty("reserved.noresult");
	String tokenPropertyName = message.getInvocationProperty("token.property.name");
	String successTokenPropertyPattern = message.getInvocationProperty("success.token.property.pattern");
	String retryTokenPropertyPattern = message.getInvocationProperty("retry.token.property.pattern");
	
	if (src instanceof List)
	{
	  logger.info("WorkflowTokenResultResponseReadTransformer payload list instance=" + src);
	  List<ch.dunes.vso.webservice.WorkflowTokenAttribute>  tokenResultList = (List<ch.dunes.vso.webservice.WorkflowTokenAttribute>)src;
		  
      String[] errorMessages = noResultCode.split(",");
	  response.setStatus(getStatus(errorMessages[0], errorMessages[1]));		  

	  if (tokenResultList != null && !tokenResultList.isEmpty())
	  {
	     logger.info("WorkflowTokenResultResponseReadTransformer: list size=" + tokenResultList.size());
	     for (ch.dunes.vso.webservice.WorkflowTokenAttribute tokenAttribute : tokenResultList)
	     {
	    	 WorkflowTokenAttribute attribute = new WorkflowTokenAttribute();
	    	 attribute.setName(tokenAttribute.getName());
	    	 attribute.setType(tokenAttribute.getType());
	    	 attribute.setValue(tokenAttribute.getValue());
		
	    	 workflowTokenAttributes.add(attribute);
		
	    	 if (attribute.getName().equalsIgnoreCase(tokenPropertyName)){
	    		 logger.info("WorkflowTokenResultResponseReadTransformer: tokenProperty=" + attribute.getValue());
	    		 logger.info("WorkflowTokenResultResponseReadTransformer: retryTokenPropertyPattern=" + retryTokenPropertyPattern);
	    		 logger.info("WorkflowTokenResultResponseReadTransformer: successTokenPropertyPattern=" + successTokenPropertyPattern);
	    		 if (attribute.getValue().matches(successTokenPropertyPattern)){
	    			 checkSuccessReturnCode = true;
	    			 logger.info("WorkflowTokenResultResponseReadTransformer: workflow executed successfully, ibroker returns success=" + checkSuccessReturnCode);
	    		 }
	    		 else if (attribute.getValue().matches(retryTokenPropertyPattern)){
	    			 checkRetryReturnCode = true;
	    			 logger.info("WorkflowTokenResultResponseReadTransformer: workflow retry mode, ibroker returns retry=" + checkRetryReturnCode);
	    		 }	    		 
	    		 else {	  
	    			 logger.info(
	    			"WorkflowTokenResultResponseReadTransformer: workflow token property pattern not matching, ibroker returns failure["
	    			+ checkRetryReturnCode + "," + checkSuccessReturnCode + "]");
	    		 }
	    	 }
	     }
	  
	     response.setWorkflowTokenAttribute(workflowTokenAttributes);
	  
	     if (checkSuccessReturnCode){
		    String[] successMessages = successCode.split(",");
		    response.setStatus(getStatus(successMessages[0], successMessages[1]));	    	 
	     }
	     else if (checkRetryReturnCode){
		    String[] retryMessages = retryCode.split(",");
		    response.setStatus(getStatus(retryMessages[0], retryMessages[1]));	    	 
	     }
	     
	  }

	  result = response;	  
	}
	else
	{
	  logger.error("Not a valid response..." + src);
	  String[] errorMessages = errorCode.split(",");
	  response.setStatus(getStatus(errorMessages[0], errorMessages[1]));

	  result = response;	  
	}
		
	return result;
  }

  private Status getStatus(String code, String description)
  {
	Status status = new Status();
	status.setStatusCode(code);
	status.setStatusDescription(description);
	
	return status;
  }
  
}

		