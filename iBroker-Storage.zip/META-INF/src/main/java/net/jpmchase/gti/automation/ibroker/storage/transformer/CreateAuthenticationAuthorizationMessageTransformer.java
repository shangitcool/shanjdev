package net.jpmchase.gti.automation.ibroker.storage.transformer;

import org.mule.api.MuleMessage;
//import org.mule.api.config.MuleProperties;
//import org.mule.api.transport.PropertyScope;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;
import org.apache.commons.codec.binary.Base64;

import net.jpmc.gti.automation.security.v2.AuthenticationAuthorizationRequest;

//import java.util.List;
//import java.util.Arrays;

public class CreateAuthenticationAuthorizationMessageTransformer extends AbstractMessageTransformer
{
  @Override
  public AuthenticationAuthorizationRequest transformMessage(MuleMessage message, String outputEncoding)
  	throws TransformerException 
  {
	String strEncodedCredential = null;
	AuthenticationAuthorizationRequest request = new AuthenticationAuthorizationRequest();
	
	String solutionName = message.getInvocationProperty("solution.name");	
	String orderID = message.getInvocationProperty("order.id");	

	request.setSourceName("iBroker-Storage");
	request.setCorrelationID(solutionName + ":" + orderID);
	
	String strBasicCredential = (String)message.getInvocationProperty("userAuth");	
	if (strBasicCredential != null)
	{
	  String[] strArray = strBasicCredential.split(" ");
	  if (strArray.length > 1){
		  strEncodedCredential = strArray[1];
	  }
	}
	
	logger.info("Checking encoded credential, value=" + strEncodedCredential);
	if (strEncodedCredential == null)
	{
	  String errorMessage = "Unable to authenticate user";
	  RuntimeException e = new RuntimeException(errorMessage);
	  logger.error(e);
	  throw e;
	}

	logger.info("Decoding base64 of =" + strEncodedCredential);
	byte[] decodedBytes = Base64.decodeBase64(strEncodedCredential.getBytes());
	String strDecodedCredential = new String(decodedBytes); 
	
	String[] decodedCredential = strDecodedCredential.split(":");
	if (decodedCredential != null && decodedCredential.length > 1)
	{
	  logger.info("Setting userid/password");
	  request.setUserID(decodedCredential[0]);
	  request.setPassword(decodedCredential[1]);
	}
	
	logger.info("Done decoding, request[source=" 
				+ request.getSourceName() 
				+ ",userid=" + request.getUserID()
				+ "]");
	return request;
  }
  
}
