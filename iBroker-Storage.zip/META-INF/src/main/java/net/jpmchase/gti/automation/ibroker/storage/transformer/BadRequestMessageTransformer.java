package net.jpmchase.gti.automation.ibroker.storage.transformer;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;
import org.mule.api.MuleMessage;

public class BadRequestMessageTransformer extends AbstractMessageTransformer
{
  @Override
  public Object transformMessage(MuleMessage src, String outputEncoding)
	throws TransformerException
  {
	src.setOutboundProperty("http.status", "400");
	
	return null;
  }
}
