package net.jpmchase.gti.automation.ibroker.storage.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="workflowTokenRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowTokenRequest")
public class WorkflowTokenRequest extends WorkflowRequest
{
  @XmlElement(name="workflowTokenId", required=false)  
  private String workflowTokenId;
	  
  public String getWorkflowTokenId() {
	return workflowTokenId;
  }

  public void setWorkflowTokenId(String workflowTokenId) {
	this.workflowTokenId = workflowTokenId;
  }

}
