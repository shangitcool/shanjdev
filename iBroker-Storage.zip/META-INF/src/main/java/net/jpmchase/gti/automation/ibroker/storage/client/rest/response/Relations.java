package net.jpmchase.gti.automation.ibroker.storage.client.rest.response;

import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect
public class Relations 
{
  private ArrayList<FlowReference> link;

  public ArrayList<FlowReference> getLink() {
	return link;
  }

  public void setLink(ArrayList<FlowReference> link) {
	this.link = link;
  } 
}
