package net.jpmchase.gti.automation.ibroker.storage.client.transformer;

import java.net.URL;

import javax.xml.namespace.QName;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.api.transport.PropertyScope;
import org.mule.transformer.AbstractMessageTransformer;

import org.apache.log4j.Logger;
//import org.springframework.util.StringUtils;
import org.apache.commons.codec.binary.Base64;

import java.util.HashMap;
import com.jpmc.gti.automation.crypto.DESCipherUtility;

import net.jpmchase.gti.automation.ibroker.security.v3.IBrokerSecurityV3Service;
import net.jpmchase.gti.automation.ibroker.security.v3.IBrokerSecurityV3ServiceService;
import net.jpmchase.gti.automation.ibroker.security.v3.ReadUserRequest;
import net.jpmchase.gti.automation.ibroker.security.v3.ReadUserResponse;

public abstract class VCOPayloadTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(VCOPayloadTransformer.class);
	
  protected String vcoURL;
  
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {
	Object result = null;
	String vcoPassword = null;
	Object src = message.getPayload();
	
	logger.info("PayloadTransformer received payload src=" + src);
	
	String vcoUser = message.getInvocationProperty("app.vco.user");
	String securityURL = message.getInvocationProperty("app.security.url.v3");
	vcoURL = message.getInvocationProperty("appVcoUrl");
	vcoPassword = net.jpmchase.gti.automation.ibroker.storage.EndpointUserCacheCollection.getPassword(vcoUser) ;
	
	if (vcoPassword == null || vcoUser.equals(vcoPassword))
	{
	  vcoPassword = _getEndpointPassword(securityURL, vcoUser);
	  net.jpmchase.gti.automation.ibroker.storage.EndpointUserCacheCollection.cacheUser(vcoUser, vcoPassword);
	}
		
	//Need to catch for NullPointerException, not a good practice
	logger.info("Retrieved endpoint credential=" + vcoUser + ":" + new String(Base64.encodeBase64(vcoPassword.getBytes())));
	
	String credential = vcoUser + ":" + vcoPassword;
	//message.setInvocationProperty("vcoAuthCredential", credential);
	message.setProperty("vcoAuthCredential", credential, PropertyScope.OUTBOUND);
	
	HashMap<String, String> outboundProperties = new HashMap<String, String>();
	
	result = _process(message, src, vcoUser, vcoPassword, outboundProperties);
	
	message.setProperty("vcoContextURL", outboundProperties.get("vcoContextURL"), PropertyScope.OUTBOUND);
	
	return result;
  }
  
  protected abstract Object _process(MuleMessage message, Object src, String vcoUserName, String vcoPassword, HashMap<String, String> outboundProperties);
    
  protected void _validateParameter(String domain, String value)
  {
	if (isNullOrEmpty(domain) || isNullOrEmpty(value))
	{
	  //throw an Invalid argument exception  
	  //throw new InvalidDataException("Not a valid arguments passed");		  
	}	  
  }
  
  protected String getVCOUrl(String fqdn)
  {
	String vcoUrlValue = vcoURL;
	  
	if (vcoURL.indexOf("{") >= 0 && vcoURL.indexOf("}")>0)
	{
	  vcoUrlValue = fqdn.trim() + vcoURL.substring(vcoURL.indexOf("}")+1);
	}

	logger.info("getVCOUrl() Returns=" + vcoUrlValue);
	  
	return vcoUrlValue;	  
  }
  
  protected boolean isNullOrEmpty(String check) {
		return (null == check || check.isEmpty());
	  }

  private String _getEndpointPassword(String securityURL, String userID)
  {
	String password = null;	
	IBrokerSecurityV3Service service =  _createSecurityStub(securityURL);
	
	ReadUserRequest request = new ReadUserRequest();
	request.setSolutionName("iBroker-Storage");
	request.setUserID(userID);
	
	ReadUserResponse response = service.readUserEntry(request);
	logger.info("Endpoint encrypted password=" + response.getPassword());
	
	if (response.getPassword() != null)
	{
	  try
	  {
	    DESCipherUtility utility = DESCipherUtility.getInstance();
	    password = utility.decrypt(response.getPassword());		
	  }
	  catch(Exception e)
	  {
		logger.error("An error occurred while decrypting the endpoint password=" + response.getPassword(), e);
		//Not stopping the process, assuming password as user id
	  }
	}
	else
	{
	  logger.error("Endpoint encrypted password is null, response=" + response);		
	}
		
	logger.info("Done _getEndpointPassword()");
	return password;
  }

  private IBrokerSecurityV3Service _createSecurityStub(String securityURL)
  {
	String wsdlURL = securityURL + "?wsdl";
	IBrokerSecurityV3Service stub = null;

	logger.info("start creating Security service stub!");		
	try
	{		  
	  String nameSpace = "http://v3.security.ibroker.automation.gti.jpmchase.net/";
	  String serviceName = "IBrokerSecurityV3ServiceService";

	  logger.debug("Creating Security stub for endpoint=" + wsdlURL);
	  
	  URL url = new URL(wsdlURL);
	  QName qname = new QName(nameSpace, serviceName);
	  IBrokerSecurityV3ServiceService service = new IBrokerSecurityV3ServiceService(url, qname);
	  stub = service.getIBrokerSecurityV3ServicePort();
	  logger.debug("Returning client isntance, stub=" + stub);
	}
	catch(Exception e)
	{
	  String message = "Error while creating security stubs, endpoint=" + wsdlURL;
	  logger.error(message, e);
	  
	  throw new RuntimeException(e);
	}
	
	logger.debug("Done creating security service stub!");
	return stub;	  
  }
  
}