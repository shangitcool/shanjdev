package net.jpmchase.gti.automation.ibroker.storage.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import net.jpmchase.gti.automation.ibroker.storage.Status;

@XmlRootElement(name="storageDeviceResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="storageDeviceResponse")
public class StorageDeviceResponse 
{
  @XmlElement(name="VMDiskUUID", required=false)  
  private String VMDiskUUID; 
  @XmlElement(name="SCSIID", required=false)  
  private String SCSIID; 
  @XmlElement(name="diskName", required=false)  
  private String diskName;
  @XmlElement(name="NAAID", required=false)  
  private String NAAID;  
  
  @XmlElement(name="status", required=true)  
  private Status status;

  
public String getVMDiskUUID() {
	return VMDiskUUID;
}
public void setVMDiskUUID(String vMDiskUUID) {
	VMDiskUUID = vMDiskUUID;
}
public String getSCSIID() {
	return SCSIID;
}
public void setSCSIID(String sCSIID) {
	SCSIID = sCSIID;
}
public String getDiskName() {
	return diskName;
}
public void setDiskName(String diskName) {
	this.diskName = diskName;
}
public String getNAAID() {
	return NAAID;
}
public void setNAAID(String nAAID) {
	NAAID = nAAID;
}
  
public Status getStatus() {
	return status;
}
public void setStatus(Status status) {
	this.status = status;
}
  
  
}