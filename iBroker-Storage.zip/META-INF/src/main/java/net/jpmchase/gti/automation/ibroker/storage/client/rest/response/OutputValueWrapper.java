package net.jpmchase.gti.automation.ibroker.storage.client.rest.response;

import org.codehaus.jackson.annotate.JsonAutoDetect;
//import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonAutoDetect
//@JsonIgnoreProperties({"number"})
public class OutputValueWrapper 
{
  private ValueWrapper string;
  private ValueWrapper number;
  
  public ValueWrapper getString() {
	return string;
  }

  public void setString(ValueWrapper string) {
	this.string = string;
  }

  public ValueWrapper getNumber() {
	return number;
  }

  public void setNumber(ValueWrapper number) {
	this.number = number;
  } 
}
