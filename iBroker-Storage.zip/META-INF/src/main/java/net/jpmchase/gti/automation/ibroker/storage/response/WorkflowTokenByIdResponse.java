package net.jpmchase.gti.automation.ibroker.storage.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import net.jpmchase.gti.automation.ibroker.storage.Status;

@XmlRootElement(name="workflowTokenByIdResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowTokenByIdResponse")
public class WorkflowTokenByIdResponse 
{
  @XmlElement(name="id", required=false)  
  private String id;
    
  @XmlElement(name="title", required=false)  
  private String title;

  @XmlElement(name="workflowId", required=false)  
  private String workflowId;

  @XmlElement(name="currentItemName", required=false)  
  private String currentItemName;

  @XmlElement(name="currentItemState", required=false)  
  private String currentItemState;

  @XmlElement(name="globalState", required=false)  
  private String globalState;

  @XmlElement(name="businessState", required=false)  
  private String businessState;

  @XmlElement(name="startDate", required=false)  
  private String startDate;

  @XmlElement(name="endDate", required=false)  
  private String endDate;

  @XmlElement(name="xmlContent", required=false)  
  private String xmlContent;

  
  @XmlElement(name="status", required=true)  
  private Status status;
  
public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getWorkflowId() {
	return workflowId;
}

public void setWorkflowId(String workflowId) {
	this.workflowId = workflowId;
}

public String getCurrentItemName() {
	return currentItemName;
}

public void setCurrentItemName(String currentItemName) {
	this.currentItemName = currentItemName;
}

public String getCurrentItemState() {
	return currentItemState;
}

public void setCurrentItemState(String currentItemState) {
	this.currentItemState = currentItemState;
}

public String getGlobalState() {
	return globalState;
}

public void setGlobalState(String globalState) {
	this.globalState = globalState;
}

public String getBusinessState() {
	return businessState;
}

public void setBusinessState(String businessState) {
	this.businessState = businessState;
}

public String getStartDate() {
	return startDate;
}

public void setStartDate(String startDate) {
	this.startDate = startDate;
}

public String getEndDate() {
	return endDate;
}

public void setEndDate(String endDate) {
	this.endDate = endDate;
}

public String getXmlContent() {
	return xmlContent;
}

public void setXmlContent(String xmlContent) {
	this.xmlContent = xmlContent;
}


public Status getStatus() {
	return status;
}
public void setStatus(Status status) {
	this.status = status;
}
  
  
}
