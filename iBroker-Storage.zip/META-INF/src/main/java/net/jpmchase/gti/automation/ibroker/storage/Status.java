package net.jpmchase.gti.automation.ibroker.storage;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="status")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="status", propOrder={
		"statusCode",
		"statusDescription"})
public class Status 
{
  @XmlElement(name="statusCode")
  private String statusCode;
  @XmlElement(name="statusDescription")
  private String statusDescription;
  
  public String getStatusCode() {
	return statusCode;
  }
  
  public void setStatusCode(String statusCode) {
	this.statusCode = statusCode;
  }
  
  public String getStatusDescription() {
	return statusDescription;
  }
  
  public void setStatusDescription(String statusDescription) {
	this.statusDescription = statusDescription;
  }
}
