package net.jpmchase.gti.automation.ibroker.storage.response;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlElement;

@XmlRootElement(name="pingResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="pingResponse")
public class PingResponse 
{
  @XmlElement(name="version", required=false)
  public String version;
  @XmlElement(name="appStatus", required=true)
  public String appStatus;

  public String getVersion() {
	return version;
  }

  public void setVersion(String version) {
	this.version = version;
  }

  public String getAppStatus() {
	return appStatus;
  }

  public void setAppStatus(String appStatus) {
	this.appStatus = appStatus;
  }
  
}
