package net.jpmchase.gti.automation.ibroker.storage;

//import java.lang.Enum;
import javax.xml.namespace.QName;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.binding.soap.interceptor.Soap11FaultOutInterceptor;
import org.apache.cxf.jaxws.interceptors.WebFaultOutInterceptor;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.Phase;

import org.apache.log4j.Logger;

public class IBrokerStorageCustomFaultInterceptor extends AbstractSoapInterceptor
{
	private static final Logger logger = Logger.getLogger(IBrokerStorageCustomFaultInterceptor.class);
	
	public String illegalArgumentError; //${ILLEGAL_ARGUMENT_ERROR}, java.lang.IllegalArgumentException
	public String sordTimeoutError; //${SORD_TIMEOUT_ERROR}, java.net.SocketTimeoutException
	public String sordConnectionError; //${SORD_CONNECTION_ERROR}, java.net.ConnectException, java.lang.RuntimeException
	public String parseError; //${PARSE_ERROR}, org.xml.sax.SAXParseException
	public String requestFailed; //${REQUEST_FAILED}, otherwise
	
	
	public IBrokerStorageCustomFaultInterceptor()
	{
		super(Phase.MARSHAL);
		getAfter().add(WebFaultOutInterceptor.class.getName()); 
        getAfter().add(Soap11FaultOutInterceptor.class.getName()); 
	}
	
	public String getIllegalArgumentError() {
		return illegalArgumentError;
	}

	public void setIllegalArgumentError(String illegalArgumentError) {
		this.illegalArgumentError = illegalArgumentError;
	}

	public String getSordTimeoutError() {
		return sordTimeoutError;
	}

	public void setSordTimeoutError(String sordTimeoutError) {
		this.sordTimeoutError = sordTimeoutError;
	}

	public String getSordConnectionError() {
		return sordConnectionError;
	}

	public void setSordConnectionError(String sordConnectionError) {
		this.sordConnectionError = sordConnectionError;
	}

	public String getParseError() {
		return parseError;
	}

	public void setParseError(String parseError) {
		this.parseError = parseError;
	}

	public String getRequestFailed() {
		return requestFailed;
	}

	public void setRequestFailed(String requestFailed) {
		this.requestFailed = requestFailed;
	}

	
	public void handleMessage(SoapMessage message) throws Fault
	{
		Fault fault = (Fault)message.getContent(Exception.class);
		Throwable throwable = getActualCause(fault.getCause());
		
		logger.error("Sord fault message=" + fault.getMessage());
		logger.error("Sord fault cause=" + fault.getCause());
		logger.info("Checking throwable in interceptor:" + message.toString());		
		if (throwable == null)
		{
		  fault.setFaultCode(new QName("FATAL"));		  
		  fault.setMessage("An invalid exception occurred");
		}
		else if (throwable instanceof IllegalArgumentException && illegalArgumentError != null)
		{
		  logger.info("Checking illegalarugment in interceptor");
		  setFaultValue(illegalArgumentError, throwable, fault);
		}		
		else if (throwable instanceof java.net.SocketTimeoutException && sordTimeoutError != null)
		{
		  setFaultValue(sordTimeoutError, throwable, fault);	
		}
		else if (throwable instanceof java.net.ConnectException && sordConnectionError != null)
		{
		  setFaultValue(sordConnectionError, throwable, fault);			
		}
		else if (throwable instanceof RuntimeException && sordConnectionError != null)
		{
		  logger.info("Checking  runtime exception in interceptor");
		  logger.info("Checking  runtime exception in interceptor, value=" + throwable);
		  setFaultValue(sordConnectionError, throwable, fault);
		}
		else if (throwable instanceof org.xml.sax.SAXParseException && parseError != null)
		{
		  setFaultValue(parseError, throwable, fault);	
		}
		else
		{
		  logger.info("Checking  default in interceptor");
		  setFaultValue(requestFailed, throwable, fault);	
		}
	
		logger.info("done Checking  in interceptor:" + throwable);
	}

	
	private void setFaultValue(String errorMessage, Throwable throwable, Fault fault)
	{
	  String[] errors = errorMessage.split(",");
	  fault.setFaultCode(new QName(errors[0]));		  
	  fault.setMessage(errors[1] + "," + throwable.toString());		
	}
	
	private Throwable getActualCause(Throwable throwable)
	{
		logger.info("getActualCauseinterceptor:" + throwable);
		if (throwable.getCause() == null || throwable.getCause().equals(throwable))
		{
		  return throwable;
		}
		else
		{
		  return getActualCause(throwable);
		}
		
	}	
}


