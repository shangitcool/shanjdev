package net.jpmchase.gti.automation.ibroker.storage.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowByNameRequest;

@XmlRootElement(name="workflowByNameResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowByNameResponse")
public class WorkflowByNameResponse extends WorkflowResponse
{
  @XmlTransient
  private WorkflowByNameRequest request;

  public WorkflowByNameRequest getRequest() {
	return request;
  }

  public void setRequest(WorkflowByNameRequest request) {
	this.request = request;
  }

}
