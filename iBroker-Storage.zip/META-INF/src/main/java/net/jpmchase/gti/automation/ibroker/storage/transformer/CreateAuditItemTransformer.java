package net.jpmchase.gti.automation.ibroker.storage.transformer;

import com.jpmc.gti.automation.audit.CreateAuditItemRequest;

import org.mule.api.MuleMessage;

import org.apache.log4j.Logger;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class CreateAuditItemTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(CreateAuditItemTransformer.class);
  
  @Override
  public CreateAuditItemRequest transformMessage(MuleMessage message, String outputencoding)
  	throws TransformerException
  {	  
	CreateAuditItemRequest request = new CreateAuditItemRequest();
	Object src = message.getPayload();
	String strXML = null;
	String userID = null;
	
	String solutionName = message.getInvocationProperty("solution.name");	
	String orderID = message.getInvocationProperty("order.id");	

	if (src instanceof String)
	{
	  strXML = (String)src;	  
	}
	else
	{
	  logger.debug("Not a valid payload type, src=" + src);
	}
	
	request.setMessageText(strXML);
	request.setSource("ibroker-sord");
	request.setUserID(userID);
	request.setCorrelationID(solutionName + ":" + orderID);
	
	return request;		
  }
}

