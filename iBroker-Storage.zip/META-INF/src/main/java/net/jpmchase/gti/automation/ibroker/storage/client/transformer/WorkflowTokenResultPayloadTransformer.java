package net.jpmchase.gti.automation.ibroker.storage.client.transformer;

import java.util.HashMap;

import org.apache.log4j.Logger;
import org.mule.api.MuleMessage;
import org.mule.api.transport.PropertyScope;

import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowTokenResultRequest;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowTokenResultResponse;

public class WorkflowTokenResultPayloadTransformer extends VCOPayloadTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowTokenResultPayloadTransformer.class);
	
  protected Object _process(MuleMessage message, Object src, String vcoUserName, String vcoPassword, HashMap<String, String> outboundProperties)
  {
	Object result = null;
	
	if (src instanceof WorkflowTokenResultResponse)
	{
	  WorkflowTokenResultResponse response  = (WorkflowTokenResultResponse)src;
	  WorkflowTokenResultRequest request = response.getRequest();

	  String vcoUrlValue = getVCOUrl(request.getVCOFQDN());	  
	  logger.info("VCO Instance url=" + vcoUrlValue);

	  //message.setInvocationProperty("vcoContextURL", vcoUrlValue);
	  //message.setProperty("vcoContextURL", vcoUrlValue, PropertyScope.OUTBOUND);
	  
	  outboundProperties.put("vcoContextURL", vcoUrlValue);
	  
	  result = getPayload(request.getWorkflowTokenId(), vcoUserName, vcoPassword);
	}	
	else
	{
	  logger.error("Not a valid request..." + src);
	}

	return result;
  }
  
  
  private Object[] getPayload(String workflowTokenId, String vcoUserName, String vcoPassword)
  {
	logger.info("getPayload()received [workflowToekn Id= " + workflowTokenId + ", vcoUserName=" + vcoUserName + "]");
	
	Object[] objectArray = {workflowTokenId, vcoUserName, vcoPassword};
	return objectArray;
  }
      
}