package net.jpmchase.gti.automation.ibroker.storage.transformer;

import net.jpmc.gti.automation.security.v2.AuthenticationAuthorizationResponse;
import net.jpmc.gti.automation.security.v2.AuthenticationAuthorizationResponse.UserRoles;
import net.jpmc.gti.automation.security.v2.GroupAndRoles.RoleAndPermissions;
import net.jpmc.gti.automation.security.v2.RoleAndPermission;
import net.jpmc.gti.automation.security.v2.GroupAndRoles;

import net.jpmc.gti.automation.security.v2.Status;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import java.util.List;
import java.util.ArrayList;

import org.apache.log4j.Logger;

@SuppressWarnings("serial")
public class ValidateUserPermissionTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(ValidateUserPermissionTransformer.class);
  private final ArrayList<String> readOperations = new ArrayList<String>()
					{{add("readSanReservation");}};					
  private final ArrayList<String> writeOperations = new ArrayList<String>()
						{{add("createSanPoolReservation");}};
  
  public Object transformMessage(MuleMessage message, String outputEncoding)
  	throws TransformerException
  {  	  
	ArrayList<String> permissionList = new ArrayList<String>();
	AuthenticationAuthorizationResponse response = (AuthenticationAuthorizationResponse)message.getPayload();
	Status status = response.getStatus();		
	
	logger.info("Authentication status=" + status);
	if (status != null){logger.info("Authentication status value=" + status.getStatusCode());}
	
	if (status != null && ("failure".equalsIgnoreCase(status.getStatusCode()) 
							|| !status.getStatusCode().startsWith("I")							
							))
	{
	  String errorMessage = "An error occurred while reading LDAP group, error=" + status.getStatusDescription();
	  RuntimeException e = new RuntimeException(errorMessage);	  
	  logger.error(errorMessage, e);
		  
	  throw e;
	}
	
	UserRoles userRoles = response.getUserRoles();
	List<GroupAndRoles> groupRolesList = userRoles.getUserRole();		
	for (GroupAndRoles groupAndRoles : groupRolesList)
	{
	  String groupName = groupAndRoles.getGroupName();
	  logger.info("Group name=" + groupName);
	  //if (groupName != null && groupName.startsWith("iBroker-SORD"))		  
	  {
		RoleAndPermissions roleAndPermissions =  groupAndRoles.getRoleAndPermissions();
		List<RoleAndPermission> roleAndPermissionList = roleAndPermissions.getRoleAndPermission();
		for (RoleAndPermission roleAndPermission : roleAndPermissionList)
		{
		  permissionList.add(roleAndPermission.getPermissionValue());
		}		
	  }
	}
	
	String operationName = message.getInvocationProperty("SOAPAction");	
	logger.info("operationName=" + operationName + ",Permission list size=" + permissionList.size());

	if ( !((readOperations.contains(operationName) && permissionList.contains("Read")) ||
		  (writeOperations.contains(operationName) && permissionList.contains("Write"))) )		
	{
	  String errorMessage = "Not an authorized user to perform this task, groupRole=" + groupRolesList;
	  RuntimeException e = new RuntimeException(errorMessage);	  
	  logger.error(errorMessage, e);
				  
	  throw e;	
	}
			
	return response;  
  }
}

