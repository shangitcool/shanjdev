package net.jpmchase.gti.automation.ibroker.storage.transformer;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;
import org.mule.api.MuleMessage;

import org.apache.log4j.Logger;

public class JSONStorageReadResponseTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(JSONStorageReadResponseTransformer.class);

  @Override
  public String transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {  	
	String returnValue = null;
	logger.info("starting transformMessage(), payload=" + message.getPayload());
	
	String value  = (String)message.getPayload();

	logger.info("Input value=" + value + ",return value=" + returnValue);
	logger.info("Done transformMessage()");
	
	return returnValue;
  }
    
}

