package net.jpmchase.gti.automation.ibroker.storage.client.transformer;


import org.apache.log4j.Logger;
import org.mule.api.MuleMessage;
import org.mule.api.transport.PropertyScope;

import net.jpmchase.gti.automation.ibroker.storage.WorkflowTokenAttribute;
import net.jpmchase.gti.automation.ibroker.storage.request.RunWorkflowRequest;
import net.jpmchase.gti.automation.ibroker.storage.response.RunWorkflowResponse;

import java.util.ArrayList;
import java.util.HashMap;

public class ExecuteWorkflowPayloadTransformer extends VCOPayloadTransformer
{
  private static final Logger logger = Logger.getLogger(ExecuteWorkflowPayloadTransformer.class);
	
  protected Object _process(MuleMessage message, Object src, String vcoUserName, String vcoPassword, HashMap<String, String> outboundProperties)
  {
	Object result = null;
	
	if (src instanceof RunWorkflowResponse)
	{
	  RunWorkflowResponse response  = (RunWorkflowResponse)src;
	  RunWorkflowRequest request = response.getRequest();

	  String vcoUrlValue = getVCOUrl(request.getVCOFQDN());	  
	  logger.info("VCO Instance url=" + vcoUrlValue);
	  
	  //message.setInvocationProperty("vcoContextURL", vcoUrlValue);
	  //message.setProperty("vcoContextURL", vcoUrlValue,PropertyScope.OUTBOUND);
	  
	  outboundProperties.put("vcoContextURL", vcoUrlValue);
	  
	  result = getPayload(request.getWorkflowId(), vcoUserName, vcoPassword, request.getWorkflowInputs());
	}	
	else
	{
	  logger.error("Not a valid request..." + src);
	}

	return result;
  }
  
  
  private Object[] getPayload(String workflowId, String vcoUserName, String vcoPassword, ArrayList<WorkflowTokenAttribute> tokenAttributes)
  {
	logger.info("getPayload()received [workflowId= " + workflowId + ", size=" + tokenAttributes.size() + "]");
	
	ArrayList<ch.dunes.vso.webservice.WorkflowTokenAttribute> attributes = new ArrayList<ch.dunes.vso.webservice.WorkflowTokenAttribute>();
	
	for (WorkflowTokenAttribute tokenAttribute : tokenAttributes)
	{
	  ch.dunes.vso.webservice.WorkflowTokenAttribute attribute = new ch.dunes.vso.webservice.WorkflowTokenAttribute();
	  attribute.setName(tokenAttribute.getName());
	  attribute.setType(tokenAttribute.getType());
	  attribute.setValue(tokenAttribute.getValue());
	  
	  attributes.add(attribute);
	}
	
		
	Object[] objectArray = {workflowId, vcoUserName, vcoPassword, attributes};
	return objectArray;
  }
      
}