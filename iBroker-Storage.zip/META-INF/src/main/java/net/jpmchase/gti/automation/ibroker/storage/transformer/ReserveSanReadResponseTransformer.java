package net.jpmchase.gti.automation.ibroker.storage.transformer;


import sord.reserve_san_webservice_wsdl.types.GetSanReservedRecUserArray;
import sord.reserve_san_webservice_wsdl.types.GetSanReservedRecUser;
import sord.reserve_san_webservice_wsdl.types.SanPoolReservedRecUserArray;
import sord.reserve_san_webservice_wsdl.types.SanPoolReservedRecUser;

import java.util.Calendar;
import java.util.List;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.response.ReserveSanPoolResponse;
import net.jpmchase.gti.automation.ibroker.storage.response.ReserveSanResponse;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;
import org.mule.api.MuleMessage;

import javax.xml.datatype.XMLGregorianCalendar;
import org.apache.log4j.Logger;

public class ReserveSanReadResponseTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(ReserveSanReadResponseTransformer.class);
  protected static String SORD_RESERVED_FAILED;
  protected static String SORD_RESERVED_SUCCESS;
  protected static String SORD_NO_RESULT;  

  
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {  
	Object returnObject = null;
	
	SORD_RESERVED_SUCCESS = message.getInvocationProperty("reserved.success");
	SORD_RESERVED_FAILED = message.getInvocationProperty("reserved.failed");
	SORD_NO_RESULT = message.getInvocationProperty("reserved.noresult");	
	
	Object object = message.getPayload();
	
    logger.info("ReserveSanReadResponseTransformer - Response =" + object);
    
    if (object instanceof GetSanReservedRecUserArray)
    {
      GetSanReservedRecUserArray sanArray = (GetSanReservedRecUserArray)object;
      ReserveSanResponse response = new ReserveSanResponse();
      
      List<GetSanReservedRecUser> sanReservedList = sanArray.getGetSanReservedRecUser();
      
      if (sanReservedList != null && !sanReservedList.isEmpty())
      {
    	GetSanReservedRecUser recUser = sanReservedList.get(0);
    	response.setReservationMasterStatus(recUser.getResMasStatus());
    	response.setNotifiedCount(recUser.getNotifiedCnt());
    	response.setReservationLOB(recUser.getResLob());
    	response.setInsertedEmail(recUser.getInsertedEmail());
    	response.setUpdatedEmail(recUser.getUpdatedEmail());
    	response.setReservationVolumeMemoryCapacityGB(recUser.getResVolmemCapgb());
    	response.setManagerEmail(recUser.getManagerEmail());
    	response.setMapFullName(recUser.getMapFullname());
    	response.setMasterUpdatedEmail(recUser.getMstrUpdatedEmail());
    	response.setReservationArrayName(recUser.getResArrayName());	
    	response.setReservationMasterCancelledDate(getCalendar(recUser.getResMasCancelledDt()));
    	response.setMasterInsertedEmail(recUser.getMstrInsertedEmail());
    	response.setFullName(recUser.getFullname());
    	response.setDeviceID(recUser.getDeviceId());
    	response.setLocalHostName(recUser.getLocalHostName());
    	response.setMapArrayName(recUser.getMapArrayName());
    	response.setReservationDetailStatus(recUser.getResDetailStatus());
    	response.setReservationFullName(recUser.getResFullname());
    	response.setReservationMasterFailedDate(getCalendar(recUser.getResMasFailedDt()));
    	response.setReservationDetailFailedReason(recUser.getResDetFailedRsn());
    	response.setReservationDetailDeployedDate(getCalendar(recUser.getResDetDeployedDt()));
    	response.setMapVolumeMemoryCapacityGB(recUser.getMapVolmemCapgb());
    	response.setReservationArraySerial(recUser.getResArraySerial());
    	response.setArchiveIndicator(recUser.getArchvInd());
  	  	response.setInsertedOn(getCalendar(recUser.getInsertedOn()));
    	response.setEndStateIdentifier(recUser.getEndStateIdentifier());
    	response.setManagerSID(recUser.getManagerSsid());
    	response.setReservationWindowOn(recUser.getResWon());
    	response.setPrimeID(recUser.getPrimeId());
    	response.setReservationMasterDeployedDate(getCalendar(recUser.getResMasDeployedDt()));
    	response.setUpdatedBy(recUser.getUpdatedBy());
    	response.setInsertedBy(recUser.getInsertedBy());
    	response.setReservationSource(recUser.getResSource());
    	response.setReservationVolumeName(recUser.getResVolumeName());    	    	
    	response.setReservationMasterSemiDeployedDate(getCalendar(recUser.getResMasSemideployedDt()));    	
    	response.setMasterInsertedOn(getCalendar(recUser.getMstrInsertedOn()));    	
    	response.setReservationVolumeType(recUser.getResVolType());
    	response.setReservationPurpose(recUser.getResPurpose());
    	response.setReservationRequestType(recUser.getResRequestType());
    	response.setReservationDetailCancelledReason(recUser.getResDetCancelledRsn());
        response.setRemoteHostName(recUser.getRemoteHostName());
        response.setReservationDetailNotifiedDate(getCalendar(recUser.getResDetNotifiedDt()));
        response.setUpdatedOn(getCalendar(recUser.getUpdatedOn()));
        response.setMasterUpdatedBy(recUser.getMstrUpdatedBy());
        response.setMasterUpdatedOn(getCalendar(recUser.getMstrUpdatedOn()));
        response.setReservationDetailRequestDate(getCalendar(recUser.getResDetRequestDt()));
        response.setMasterInsertedBy(recUser.getMstrInsertedBy());
        response.setReservationDetailID(recUser.getResDetailId());
        response.setReservationMasterID(recUser.getResMasterId());
        response.setPoolName(recUser.getPoolname());
        response.setReservationMasterDesc(recUser.getResMasDesc());
        response.setTargetDeployedDate(getCalendar(recUser.getTargetDeployedDt()));
        response.setMapArraySerial(recUser.getMapArraySerial());
        response.setReservationDetailFailedDate(getCalendar(recUser.getResDetFailedDt()));
        response.setReservationTier(recUser.getResTier());
        response.setReservationDetailCancelledDate(getCalendar(recUser.getResDetCancelledDt()));
        response.setReservationMasterRequestDate(getCalendar(recUser.getResMasRequestDt()));
        response.setReservationType(recUser.getResType());
        response.setMapVolumeName(recUser.getMapVolumeName());
       
        response.setStatus(getStatus(SORD_RESERVED_SUCCESS));
      }
      else
      {
    	//SAN services return no result
        response.setStatus(getStatus(SORD_NO_RESULT));
      }
      
      returnObject = response;
    }
    else if (object instanceof SanPoolReservedRecUserArray)
    {
      SanPoolReservedRecUserArray poolArray = (SanPoolReservedRecUserArray)object;
      ReserveSanPoolResponse response = new ReserveSanPoolResponse();
      
      List<SanPoolReservedRecUser> poolList = poolArray.getSanPoolReservedRecUser();
      
      if (poolList != null && !poolList.isEmpty())
      {
    	  SanPoolReservedRecUser poolRecUser = poolList.get(0);
    	  response.setReservationMasterStatus(poolRecUser.getResMasStatus());    
    	  response.setNotifiedCount(poolRecUser.getNotifiedCnt());
    	  response.setReservationLOB(poolRecUser.getResLob());
    	  response.setInsertedEmail(poolRecUser.getInsertedEmail());
    	  response.setUpdatedEmail(poolRecUser.getUpdatedEmail());
    	  response.setReservationVolumeMemoryCapacityGB(poolRecUser.getResVolmemCapgb());
    	  response.setManagerEmail(poolRecUser.getManagerEmail());
    	  response.setMapFullName(poolRecUser.getMapFullname());
    	  response.setMasterUpdatedEmail(poolRecUser.getMstrUpdatedEmail());
    	  response.setReservationArrayName(poolRecUser.getResArrayName());
    	  response.setReservationMasterCancelledDate(getCalendar(poolRecUser.getResMasCancelledDt()));
    	  response.setSubPolicyTier(poolRecUser.getSubPolicyTier());
    	  response.setMasterInsertedEmail(poolRecUser.getMstrInsertedEmail());
    	  response.setFullName(poolRecUser.getFullname());
          response.setDeviceID(poolRecUser.getDeviceId());
          response.setLocalHostName(poolRecUser.getLocalHostName());
          response.setMapArrayName(poolRecUser.getMapArrayName());
          response.setReservedStatus(poolRecUser.getStatus());
          response.setReservationDetailStatus(poolRecUser.getResDetailStatus());
          response.setErrorCode(poolRecUser.getErrCode());
          response.setReservationDetailFailedReason(poolRecUser.getResDetFailedRsn());
          response.setReservationFullName(poolRecUser.getResFullname());
          response.setReservationMasterFailedDate(getCalendar(poolRecUser.getResMasFailedDt()));
          response.setReservationDetailDeployedDate(getCalendar(poolRecUser.getResDetDeployedDt()));
          response.setMapVolumeMemoryCapacityGB(poolRecUser.getMapVolmemCapgb());
          response.setReservationArraySerial(poolRecUser.getResArraySerial());
          response.setErrorMessage(poolRecUser.getErrMsg());
          response.setInsertedOn(getCalendar(poolRecUser.getInsertedOn()));
          response.setEndStateIdentifier(poolRecUser.getEndStateIdentifier());
          response.setManagerSID(poolRecUser.getManagerSsid());
          response.setReservationWindowOn(poolRecUser.getResWon());
          response.setPrimeID(poolRecUser.getPrimeId());
          response.setReservationMasterDeployedDate(getCalendar(poolRecUser.getResMasDeployedDt()));
          response.setReservedTier(poolRecUser.getReservedTier());
          response.setUpdatedBy(poolRecUser.getUpdatedBy());
          response.setInsertedBy(poolRecUser.getInsertedBy());
          response.setReservationSource(poolRecUser.getResSource());
          response.setReservationVolumeName(poolRecUser.getResVolumeName());
          response.setReservationMasterSemiDeployedDate(getCalendar(poolRecUser.getResMasSemideployedDt()));
          response.setReservationVolumeType(poolRecUser.getResVolType());
          response.setReservationPurpose(poolRecUser.getResPurpose());
          response.setMasterInsertedOn(getCalendar(poolRecUser.getMstrInsertedOn()));
          response.setReservationDetailCancelledReason(poolRecUser.getResDetCancelledRsn());
          response.setReservationRequestType(poolRecUser.getResRequestType());
          response.setRemoteHostName(poolRecUser.getRemoteHostName());
          response.setReservationDetailNotifiedDate(getCalendar(poolRecUser.getResDetNotifiedDt()));
          response.setUpdatedOn(getCalendar(poolRecUser.getUpdatedOn()));
          response.setMasterUpdatedBy(poolRecUser.getMstrUpdatedBy());
          response.setMasterUpdatedOn(getCalendar(poolRecUser.getMstrUpdatedOn()));
          response.setReservationDetailRequestDate(getCalendar(poolRecUser.getResDetRequestDt()));
          response.setMasterInsertedBy(poolRecUser.getMstrInsertedBy());
          response.setReservationDetailID(poolRecUser.getResDetailId());
          response.setReservationMasterID(poolRecUser.getResMasterId());
          response.setPoolName(poolRecUser.getPoolname());
          response.setReservationMasterDesc(poolRecUser.getResMasDesc());
          response.setTargetDeployedDate(getCalendar(poolRecUser.getTargetDeployedDt()));
          response.setMapArraySerial(poolRecUser.getMapArraySerial());
          response.setReservationDetailFailedDate(getCalendar(poolRecUser.getResDetFailedDt()));
          response.setReservationDetailCancelledDate(getCalendar(poolRecUser.getResDetCancelledDt()));
          response.setReservationMasterRequestDate(getCalendar(poolRecUser.getResMasRequestDt()));
          response.setReservationType(poolRecUser.getResType());
          response.setMapVolumeName(poolRecUser.getMapVolumeName());
          
          if (response.getReservedStatus() == null || 
        		 (response.getReservedStatus() != null && response.getReservedStatus().equalsIgnoreCase("N")))
          {
        	//failed at SAN WS
        	response.setStatus(getStatus(SORD_RESERVED_FAILED));
          }
          else
          {
            response.setStatus(getStatus(SORD_RESERVED_SUCCESS));
          }
      }
      else
      {
      	  //SAN services return no result
          response.setStatus(getStatus(SORD_NO_RESULT));    	  
      }
      
      returnObject = response;
    }
    else
    {	
	  String errorMessage = "Received an invalid response object, value=" + object; 
	  logger.error(errorMessage);
	  throw new RuntimeException(errorMessage);
	  //response.setStatus(getStatus(SORD_RESERVED_FAILED));
    }
	  	  
		
	return returnObject;
  }
  
  private Calendar getCalendar(XMLGregorianCalendar value)
  {
	Calendar returnCal = null;
	
	if (value != null)
	{
	  returnCal = Calendar.getInstance();
	  returnCal.setTime(value.toGregorianCalendar().getTime());
	}
	  
	return returnCal;
  }
  
  private Status getStatus(String value)
  {
	Status status = new Status();
	String[] messages = value.split(",");
	status.setStatusCode(messages[0]);
	status.setStatusDescription(messages[1]);		
	return status;
  }
  
}
