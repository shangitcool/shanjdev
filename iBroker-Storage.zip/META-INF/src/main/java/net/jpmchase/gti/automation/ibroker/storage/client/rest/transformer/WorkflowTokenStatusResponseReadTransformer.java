package net.jpmchase.gti.automation.ibroker.storage.client.rest.transformer;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowTokenStatusResponse;
import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.WorkflowTokenStatusJSONResponse;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import java.util.ArrayList;
import org.apache.log4j.Logger;

public class WorkflowTokenStatusResponseReadTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowTokenStatusResponseReadTransformer.class);
	
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {
	WorkflowTokenStatusResponse response  = new WorkflowTokenStatusResponse();
	Object src = message.getPayload();
	
	logger.info("WorkflowTokenStatusResponseReadTransformer received payload src=" + src);

	String successCode = message.getInvocationProperty("reserved.success");
	String errorCode = message.getInvocationProperty("reserved.failed");
	String noResultCode = message.getInvocationProperty("reserved.noresult");	

	response.setStatus(getStatus(errorCode)); //assuming not-a-valid request
	if (src instanceof WorkflowTokenStatusJSONResponse)
	{
	  logger.info("WorkflowTokenStatusResponseReadTransformer: payload instance of list=" + src);
	  WorkflowTokenStatusJSONResponse workflowTokenStatusJSONResponse = (WorkflowTokenStatusJSONResponse)src;
  
	  response.setStatus(getStatus(noResultCode)); //assuming no-result from VCO
	  if (workflowTokenStatusJSONResponse != null)
	  {
		ArrayList<String> state = new ArrayList<String>();		
		state.add(workflowTokenStatusJSONResponse.getState());

		response.setReturnValues(state);
		
		response.setStatus(getStatus(successCode));
		logger.info("start-date=" + workflowTokenStatusJSONResponse.getStartdate());
		logger.info("end-date=" + workflowTokenStatusJSONResponse.getEnddate());
	  }
	  
	}

	return response;
  }

  private Status getStatus(String messageCode)
  {
	String[] messages = messageCode.split(",");
	
	Status status = new Status();
	status.setStatusCode(messages[0]);
	status.setStatusDescription(messages[1]);
	
	return status;
  }
  
}