package net.jpmchase.gti.automation.ibroker.storage.client.rest.transformer;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class PythonRunTransformer extends AbstractMessageTransformer 
{
  final Logger logger = Logger.getLogger(PythonRunTransformer.class);
	
  public String transformMessage(MuleMessage message, String outputEncoding)
  	throws TransformerException
  {
	String httpStatus = null;
	String[] returnValues = new String[] {new String(), new String()};

	try{
	  logger.info("Current dir=" + System.getProperty("user.dir"));			
			
	  //String payload = message.getPayloadAsString();
	  String guid = message.getInvocationProperty("guid");
	  logger.info("transformMessage(): Received = " + guid);
			
	  String authCookie = message.getInvocationProperty("AuthCookie");
	  String aliceContextRoot = message.getInvocationProperty("AliceContextRoot");
	  String alicePort = message.getInvocationProperty("AlicePort");
	  String aliceStatusURI = message.getInvocationProperty("AliceStatusURL");
	  String scriptWithDir = message.getInvocationProperty("AliceGetScript");
			
	  String commandWithArguments = scriptWithDir + " " + authCookie 
				+ " " + aliceContextRoot + " " + alicePort + " " + "/" + aliceStatusURI + guid;
			
	  logger.info("transformMessage(): running commandWithArguments=" + commandWithArguments);
	  Runtime runtime = Runtime.getRuntime();
	  Process process = runtime.exec(commandWithArguments);
	  InputStream is = process.getInputStream();
	  InputStreamReader isr = new InputStreamReader(is);
	  BufferedReader br = new BufferedReader(isr);
	  
      logger.info("transformMessage(): reading output");		
	  String line;
	  int i=0;
	  while ((line = br.readLine()) != null) {
		  returnValues[i] = line;
		  i++;
		  logger.info(line);
	  }

	  logger.info("transformMessage(): setting return values");		       
	  message.setInvocationProperty("aliceStatus", returnValues[0]);
	  message.setInvocationProperty("aliceResponse", returnValues[1]);	  
	} catch(Exception e) {
		logger.error(e);
		throw new RuntimeException(e);
	}
		
	return httpStatus;
  }
}
