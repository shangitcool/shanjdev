package net.jpmchase.gti.automation.ibroker.storage.transformer;

import com.jpmc.gti.automation.crypto.DESCipherUtility;
import net.jpmc.gti.automation.security.v2.IBrokerSecurityV2Service;
import net.jpmc.gti.automation.security.v2.IBrokerSecurityV2ServiceService;
import net.jpmc.gti.automation.security.v2.ReadUserRequest;
import net.jpmc.gti.automation.security.v2.ReadUserResponse;

import net.jpmchase.gti.automation.ibroker.storage.WorkflowTokenAttribute;
import net.jpmchase.gti.automation.ibroker.storage.request.ReserveSanPoolRequest;
import net.jpmchase.gti.automation.ibroker.storage.request.ReserveSanRequest;
import net.jpmchase.gti.automation.ibroker.storage.request.RunWorkflowRequest;
import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowByNameRequest;
import net.jpmchase.gti.automation.ibroker.storage.response.ReserveSanPoolResponse;
import net.jpmchase.gti.automation.ibroker.storage.response.ReserveSanResponse;
import net.jpmchase.gti.automation.ibroker.storage.response.RunWorkflowResponse;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowByNameResponse;

import org.apache.commons.codec.binary.Base64;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.api.transport.PropertyScope;
import org.mule.transformer.AbstractMessageTransformer;

import java.net.URL;
import java.util.ArrayList;
import javax.xml.namespace.QName;

import org.apache.log4j.Logger;

public class CreatePayloadTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(CreatePayloadTransformer.class);
	
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  { 
	Object returnObject = null;	
	Object src = message.getPayload();
	
	String sanUser = message.getInvocationProperty("app.san.user");	
	String securityURL = message.getInvocationProperty("app.security.url.v2");
		
	String endpointPassword = net.jpmchase.gti.automation.ibroker.storage.EndpointUserCacheCollection.getPassword(sanUser) ;
	if (endpointPassword == null || sanUser.equals(endpointPassword))
	{
	  endpointPassword = _getEndpointPassword(securityURL, sanUser);
	  net.jpmchase.gti.automation.ibroker.storage.EndpointUserCacheCollection.cacheUser(sanUser, endpointPassword);
	}
	
	String credential = sanUser + ":" + endpointPassword;	
	String encodedValue = new String(Base64.encodeBase64(credential.getBytes()));
	String basicEncodeValue = "Basic " + encodedValue;
	//message.setInvocationProperty("basicAuthorization", basicEncodeValue);
	message.setProperty("basicAuthorization", basicEncodeValue, PropertyScope.OUTBOUND);
	
	
	if (src instanceof ReserveSanResponse)
	{
	  ReserveSanResponse response = (ReserveSanResponse)src;
	  ReserveSanRequest request = response.getRequest();
	  String[] array = new String[]{request.getRequestID(), request.getSystemID(),
				request.getPrimeID(), request.getHostName(), request.getDeviceID()};
	  
	  returnObject = array;
	}
	else if (src instanceof ReserveSanPoolResponse)
	{
	  ReserveSanPoolResponse response = (ReserveSanPoolResponse)src;
	  ReserveSanPoolRequest request = response.getRequest();
	  
	  Object[] array = new Object[] {
			  				request.getRequestID(), request.getSystemID(), request.getSite(), request.getFabric(),
			  				request.getTier(), request.getPurpose(), request.getArray(), request.getPool(),
			  				request.getHostName(), request.getDeploymentDate(), request.getVolumeName(), request.getCapacity(),
			  				request.getPolicysTier(), request.getReservationDesc(), request.getReservationType(), request.getSource(),
			  				request.getLob(), request.getPrimeID(), request.getDeviceID(), request.getUser(),
			  				request.getUserEmail(), request.getManagerSID(), request.getManagerEmail()
	  								};
	  
	  returnObject = array;
	  	
	}
	else if (src instanceof WorkflowByNameResponse)
	{
	  WorkflowByNameResponse response = (WorkflowByNameResponse)src;
	  WorkflowByNameRequest request = response.getRequest();
	  
	  message.setInvocationProperty("vcoInstance", request.getVCOFQDN());
	  
	  //Remove it later
		String baValue = "Basic " + new String(Base64.encodeBase64("a_vcosituser:JP1chase@vcosituser".getBytes()));
		message.setInvocationProperty("basicAuthorization", baValue);
	  /////
	  returnObject = request.getWorkflowName();
	  
	}
	else if (src instanceof RunWorkflowResponse)
	{
	  RunWorkflowResponse response = (RunWorkflowResponse)src;
	  RunWorkflowRequest request = response.getRequest();
	  
	  message.setInvocationProperty("vcoInstance", request.getVCOFQDN());
	  message.setInvocationProperty("workflowID", request.getWorkflowId());
	  
	  //Remove it later
		String baValue = "Basic " + new String(Base64.encodeBase64("a_vcosituser:JP1chase@vcosituser".getBytes()));
		message.setInvocationProperty("basicAuthorization", baValue);
	  /////
	  
	  returnObject = getWorkflowExecutionInput(request.getWorkflowInputs());
	  
	}
	else
	{
	  String erroMessage = "Received an invalid object, src=" + src; 
	  logger.error(erroMessage);
	  throw new RuntimeException(erroMessage);
	}
	
	logger.info("paylod data=" + returnObject);
	return returnObject;
  }

  private String getWorkflowExecutionInput(ArrayList<WorkflowTokenAttribute> inputs)
  {
	String value = "<execution-context xmlns=\"http://www.vmware.com/vco\"><parameters>";
	
	for (WorkflowTokenAttribute input : inputs)
	{
	  String parameter = "<parameter type=\"" + input.getType() + "\" name=\"" + input.getName() + "\" scope=\"local\"" +
	  						"<string>" + input.getValue() + "</string>" +
	  					 "</parameter>";
	  value = value + parameter;
	}

	value = value + "</parameters></execution-context>";

	return value;
  }
 
  private String _getEndpointPassword(String securityURL, String userID)
  {
	String password = null;	
	IBrokerSecurityV2Service service =  _createSecurityStub(securityURL);
	
	ReadUserRequest request = new ReadUserRequest();
	request.setSolutionName("ibroker-sord");
	request.setUserID(userID);
	
	ReadUserResponse response = service.readUserEntry(request);
	logger.info("Endpoint encrypted password=" + response.getPassword());
	
	if (response.getPassword() != null)
	{
	  try
	  {
	    DESCipherUtility utility = DESCipherUtility.getInstance();
	    password = utility.decrypt(response.getPassword());		
	  }
	  catch(Exception e)
	  {
		logger.error("An error occurred while decrypting the endpoint password=" + response.getPassword(), e);
		//Not stopping the process, assuming password as user id
	  }
	}
	else
	{
	  logger.error("Endpoint encrypted password is null, response=" + response);	
	}
		
	logger.info("Done _getEndpointPassword()");
	return password;
  }
  
  private IBrokerSecurityV2Service _createSecurityStub(String securityURL)
  {
	String wsdlURL = securityURL + "?wsdl";
	IBrokerSecurityV2Service stub = null;

	logger.info("start creating Security service stub!");		
	try
	{		  
	  String nameSpace = "http://v2.security.automation.gti.jpmc.net/";
	  String serviceName = "IBrokerSecurityV2ServiceService";

	  logger.debug("Creating Security stub for endpoint=" + wsdlURL);
	  
	  URL url = new URL(wsdlURL);
	  QName qname = new QName(nameSpace, serviceName);
	  IBrokerSecurityV2ServiceService service = new IBrokerSecurityV2ServiceService(url, qname);
	  stub = service.getIBrokerSecurityV2ServicePort();
	  logger.debug("Returning client isntance, stub=" + stub);
	}
	catch(Exception e)
	{
	  String message = "Error while creating security stubs, endpoint=" + wsdlURL;
	  logger.error(message, e);
	  
	  throw new RuntimeException(e);
	}
	
	logger.debug("Done creating security service stub!");
	return stub;	  
  }
  
}
