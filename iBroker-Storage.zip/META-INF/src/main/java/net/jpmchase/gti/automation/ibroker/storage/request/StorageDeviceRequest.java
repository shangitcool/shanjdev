package net.jpmchase.gti.automation.ibroker.storage.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="storageDeviceRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="storageDeviceRequest")
public class StorageDeviceRequest 
{
  @XmlElement(name="solutionName", required=false)  
  private String solutionName; 
  @XmlElement(name="orderID", required=false)  
  private String orderID; 
  @XmlElement(name="machineID", required=false)  
  private String machineID;
  @XmlElement(name="VMNetworkHostname", required=true)  
  private String VMNetworkHostname;
  @XmlElement(name="clusterName", required=false)  
  private String clusterName;
  @XmlElement(name="managingIPAddress", required=false)  
  private String managingIPAddress;
  
public String getSolutionName() {
	return solutionName;
}
public void setSolutionName(String solutionName) {
	this.solutionName = solutionName;
}
public String getOrderID() {
	return orderID;
}
public void setOrderID(String orderID) {
	this.orderID = orderID;
}
public String getMachineID() {
	return machineID;
}
public void setMachineID(String machineID) {
	this.machineID = machineID;
}
public String getVMNetworkHostname() {
	return VMNetworkHostname;
}
public void setVMNetworkHostname(String vMNetworkHostname) {
	VMNetworkHostname = vMNetworkHostname;
}
public String getClusterName() {
	return clusterName;
}
public void setClusterName(String clusterName) {
	this.clusterName = clusterName;
}
public String getManagingIPAddress() {
	return managingIPAddress;
}
public void setManagingIPAddress(String managingIPAddress) {
	this.managingIPAddress = managingIPAddress;
}
  
  
}
