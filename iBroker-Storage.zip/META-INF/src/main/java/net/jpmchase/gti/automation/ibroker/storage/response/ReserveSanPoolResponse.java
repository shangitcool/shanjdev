package net.jpmchase.gti.automation.ibroker.storage.response;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlRootElement;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.request.ReserveSanPoolRequest;

import java.math.BigDecimal;
import java.util.Calendar;

@XmlRootElement(name="reserveSanPoolResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="reserveSanPoolResponse")
public class ReserveSanPoolResponse 
{	
  @XmlElement(name="reservationMasterStatus", required=false)  
  private String reservationMasterStatus; 
  @XmlElement(name="notifiedCount", required=false)  
  private BigDecimal notifiedCount;  
  @XmlElement(name="reservationLOB", required=false)  
  private String reservationLOB;  
  @XmlElement(name="insertedEmail", required=false)  
  private String insertedEmail;  
  @XmlElement(name="updatedEmail", required=false)  
  private String updatedEmail;  
  @XmlElement(name="reservationVolumeMemoryCapacityGB", required=false)  
  private BigDecimal reservationVolumeMemoryCapacityGB;
  @XmlElement(name="managerEmail", required=false)  
  private String managerEmail;
  @XmlElement(name="mapFullName", required=true)  
  private String mapFullName;
  @XmlElement(name="masterUpdatedEmail", required=true)  
  private String masterUpdatedEmail;
  @XmlElement(name="reservationArrayName", required=true)  
  private String reservationArrayName;
  @XmlElement(name="reservationMasterCancelledDate", required=true)  
  private Calendar reservationMasterCancelledDate;
  @XmlElement(name="subPolicyTier", required=true)  
  private String subPolicyTier;
  @XmlElement(name="masterInsertedEmail", required=true)  
  private String masterInsertedEmail;
  @XmlElement(name="fullName", required=true)  
  private String fullName;
  @XmlElement(name="deviceID")  
  private String deviceID;
  @XmlElement(name="localHostName")  
  private String localHostName;
  @XmlElement(name="mapArrayName")  
  private String mapArrayName;
  @XmlElement(name="reservedStatus")  
  private String reservedStatus;
  @XmlElement(name="reservationDetailStatus")  
  private String reservationDetailStatus;
  @XmlElement(name="errorCode")  
  private String errorCode;
  @XmlElement(name="reservationDetailFailedReason")  
  private String reservationDetailFailedReason;  
  @XmlElement(name="reservationFullName")  
  private String reservationFullName;  
  @XmlElement(name="reservationMasterFailedDate")  
  private Calendar reservationMasterFailedDate;  
  @XmlElement(name="reservationDetailDeployedDate")  
  private Calendar reservationDetailDeployedDate;  
  @XmlElement(name="mapVolumeMemoryCapacityGB")  
  private BigDecimal mapVolumeMemoryCapacityGB;  
  @XmlElement(name="reservationArraySerial")  
  private String reservationArraySerial;
  @XmlElement(name="errorMessage")  
  private String errorMessage;  
  @XmlElement(name="insertedOn")  
  private Calendar insertedOn;  
  @XmlElement(name="endStateIdentifier")  
  private String endStateIdentifier;  
  @XmlElement(name="managerSID")  
  private String managerSID;  
  @XmlElement(name="reservationWindowOn")  
  private String reservationWindowOn;  
  @XmlElement(name="primeID")  
  private String primeID;  
  @XmlElement(name="reservationMasterDeployedDate")  
  private Calendar reservationMasterDeployedDate;  
  @XmlElement(name="reservedTier")  
  private String reservedTier;    
  @XmlElement(name="updatedBy")  
  private String updatedBy;  
  @XmlElement(name="insertedBy")  
  private String insertedBy;  
  @XmlElement(name="reservationSource")  
  private String reservationSource;  
  @XmlElement(name="reservationVolumeName")  
  private String reservationVolumeName;
  @XmlElement(name="reservationMasterSemiDeployedDate")  
  private Calendar reservationMasterSemiDeployedDate;  
  @XmlElement(name="reservationVolumeType")  
  private String reservationVolumeType;
  @XmlElement(name="reservationPurpose")  
  private String reservationPurpose;  
  @XmlElement(name="masterInsertedOn")  
  private Calendar masterInsertedOn;
  @XmlElement(name="reservationDetailCancelledReason")  
  private String reservationDetailCancelledReason;  
  @XmlElement(name="reservationRequestType")  
  private String reservationRequestType;
  @XmlElement(name="remoteHostName")  
  private String remoteHostName;
  @XmlElement(name="reservationDetailNotifiedDate")  
  private Calendar reservationDetailNotifiedDate;  
  @XmlElement(name="updatedOn")  
  private Calendar updatedOn;
  @XmlElement(name="masterUpdatedBy")  
  private String masterUpdatedBy;
  @XmlElement(name="masterUpdatedOn")  
  private Calendar masterUpdatedOn;
  @XmlElement(name="reservationDetailRequestDate")  
  private Calendar reservationDetailRequestDate;
  @XmlElement(name="masterInsertedBy")  
  private String masterInsertedBy;
  @XmlElement(name="reservationDetailID")  
  private BigDecimal reservationDetailID;
  @XmlElement(name="reservationMasterID")  
  private BigDecimal reservationMasterID;  
  @XmlElement(name="poolName")  
  private String poolName;
  @XmlElement(name="reservationMasterDesc")  
  private String reservationMasterDesc;
  @XmlElement(name="targetDeployedDate")  
  private Calendar targetDeployedDate;  
  @XmlElement(name="mapArraySerial")  
  private String mapArraySerial;
  @XmlElement(name="reservationDetailFailedDate")  
  private Calendar reservationDetailFailedDate;  
  @XmlElement(name="reservationDetailCancelledDate")  
  private Calendar reservationDetailCancelledDate;  
  @XmlElement(name="reservationMasterRequestDate")  
  private Calendar reservationMasterRequestDate;  
  @XmlElement(name="reservationType")  
  private String reservationType;
  @XmlElement(name="mapVolumeName")  
  private String mapVolumeName;
  
  @XmlElement(name="status")  
  private Status status;

  
public String getReservationMasterStatus() {
	return reservationMasterStatus;
}
public void setReservationMasterStatus(String reservationMasterStatus) {
	this.reservationMasterStatus = reservationMasterStatus;
}
public BigDecimal getNotifiedCount() {
	return notifiedCount;
}
public void setNotifiedCount(BigDecimal notifiedCount) {
	this.notifiedCount = notifiedCount;
}
public String getReservationLOB() {
	return reservationLOB;
}
public void setReservationLOB(String reservationLOB) {
	this.reservationLOB = reservationLOB;
}
public String getInsertedEmail() {
	return insertedEmail;
}
public void setInsertedEmail(String insertedEmail) {
	this.insertedEmail = insertedEmail;
}
public String getUpdatedEmail() {
	return updatedEmail;
}
public void setUpdatedEmail(String updatedEmail) {
	this.updatedEmail = updatedEmail;
}
public BigDecimal getReservationVolumeMemoryCapacityGB() {
	return reservationVolumeMemoryCapacityGB;
}
public void setReservationVolumeMemoryCapacityGB(
		BigDecimal reservationVolumeMemoryCapacityGB) {
	this.reservationVolumeMemoryCapacityGB = reservationVolumeMemoryCapacityGB;
}
public String getManagerEmail() {
	return managerEmail;
}
public void setManagerEmail(String managerEmail) {
	this.managerEmail = managerEmail;
}
public String getMapFullName() {
	return mapFullName;
}
public void setMapFullName(String mapFullName) {
	this.mapFullName = mapFullName;
}
public String getMasterUpdatedEmail() {
	return masterUpdatedEmail;
}
public void setMasterUpdatedEmail(String masterUpdatedEmail) {
	this.masterUpdatedEmail = masterUpdatedEmail;
}
public String getReservationArrayName() {
	return reservationArrayName;
}
public void setReservationArrayName(String reservationArrayName) {
	this.reservationArrayName = reservationArrayName;
}
public Calendar getReservationMasterCancelledDate() {
	return reservationMasterCancelledDate;
}
public void setReservationMasterCancelledDate(
		Calendar reservationMasterCancelledDate) {
	this.reservationMasterCancelledDate = reservationMasterCancelledDate;
}
public String getMasterInsertedEmail() {
	return masterInsertedEmail;
}
public void setMasterInsertedEmail(String masterInsertedEmail) {
	this.masterInsertedEmail = masterInsertedEmail;
}
public String getFullName() {
	return fullName;
}
public void setFullName(String fullName) {
	this.fullName = fullName;
}
public String getDeviceID() {
	return deviceID;
}
public void setDeviceID(String deviceID) {
	this.deviceID = deviceID;
}
public String getLocalHostName() {
	return localHostName;
}
public void setLocalHostName(String localHostName) {
	this.localHostName = localHostName;
}
public String getMapArrayName() {
	return mapArrayName;
}
public void setMapArrayName(String mapArrayName) {
	this.mapArrayName = mapArrayName;
}
public String getReservationDetailStatus() {
	return reservationDetailStatus;
}
public void setReservationDetailStatus(String reservationDetailStatus) {
	this.reservationDetailStatus = reservationDetailStatus;
}
public String getReservationFullName() {
	return reservationFullName;
}
public void setReservationFullName(String reservationFullName) {
	this.reservationFullName = reservationFullName;
}
public Calendar getReservationMasterFailedDate() {
	return reservationMasterFailedDate;
}
public void setReservationMasterFailedDate(Calendar reservationMasterFailedDate) {
	this.reservationMasterFailedDate = reservationMasterFailedDate;
}
public String getReservationDetailFailedReason() {
	return reservationDetailFailedReason;
}
public void setReservationDetailFailedReason(
		String reservationDetailFailedReason) {
	this.reservationDetailFailedReason = reservationDetailFailedReason;
}
public Calendar getReservationDetailDeployedDate() {
	return reservationDetailDeployedDate;
}
public void setReservationDetailDeployedDate(
		Calendar reservationDetailDeployedDate) {
	this.reservationDetailDeployedDate = reservationDetailDeployedDate;
}
public BigDecimal getMapVolumeMemoryCapacityGB() {
	return mapVolumeMemoryCapacityGB;
}
public void setMapVolumeMemoryCapacityGB(BigDecimal mapVolumeMemoryCapacityGB) {
	this.mapVolumeMemoryCapacityGB = mapVolumeMemoryCapacityGB;
}
public String getReservationArraySerial() {
	return reservationArraySerial;
}
public void setReservationArraySerial(String reservationArraySerial) {
	this.reservationArraySerial = reservationArraySerial;
}
public Calendar getInsertedOn() {
	return insertedOn;
}
public void setInsertedOn(Calendar insertedOn) {
	this.insertedOn = insertedOn;
}
public String getEndStateIdentifier() {
	return endStateIdentifier;
}
public void setEndStateIdentifier(String endStateIdentifier) {
	this.endStateIdentifier = endStateIdentifier;
}
public String getManagerSID() {
	return managerSID;
}
public void setManagerSID(String managerSID) {
	this.managerSID = managerSID;
}
public String getReservationWindowOn() {
	return reservationWindowOn;
}
public void setReservationWindowOn(String reservationWindowOn) {
	this.reservationWindowOn = reservationWindowOn;
}
public String getPrimeID() {
	return primeID;
}
public void setPrimeID(String primeID) {
	this.primeID = primeID;
}
public Calendar getReservationMasterDeployedDate() {
	return reservationMasterDeployedDate;
}
public void setReservationMasterDeployedDate(
		Calendar reservationMasterDeployedDate) {
	this.reservationMasterDeployedDate = reservationMasterDeployedDate;
}
public String getUpdatedBy() {
	return updatedBy;
}
public void setUpdatedBy(String updatedBy) {
	this.updatedBy = updatedBy;
}
public String getInsertedBy() {
	return insertedBy;
}
public void setInsertedBy(String insertedBy) {
	this.insertedBy = insertedBy;
}
public String getReservationSource() {
	return reservationSource;
}
public void setReservationSource(String reservationSource) {
	this.reservationSource = reservationSource;
}
public String getReservationVolumeName() {
	return reservationVolumeName;
}
public void setReservationVolumeName(String reservationVolumeName) {
	this.reservationVolumeName = reservationVolumeName;
}
public Calendar getReservationMasterSemiDeployedDate() {
	return reservationMasterSemiDeployedDate;
}
public void setReservationMasterSemiDeployedDate(
		Calendar reservationMasterSemiDeployedDate) {
	this.reservationMasterSemiDeployedDate = reservationMasterSemiDeployedDate;
}
public Calendar getMasterInsertedOn() {
	return masterInsertedOn;
}
public void setMasterInsertedOn(Calendar masterInsertedOn) {
	this.masterInsertedOn = masterInsertedOn;
}
public String getReservationVolumeType() {
	return reservationVolumeType;
}
public void setReservationVolumeType(String reservationVolumeType) {
	this.reservationVolumeType = reservationVolumeType;
}
public String getReservationPurpose() {
	return reservationPurpose;
}
public void setReservationPurpose(String reservationPurpose) {
	this.reservationPurpose = reservationPurpose;
}
public String getReservationRequestType() {
	return reservationRequestType;
}
public void setReservationRequestType(String reservationRequestType) {
	this.reservationRequestType = reservationRequestType;
}
public String getReservationDetailCancelledReason() {
	return reservationDetailCancelledReason;
}
public void setReservationDetailCancelledReason(
		String reservationDetailCancelledReason) {
	this.reservationDetailCancelledReason = reservationDetailCancelledReason;
}
public String getRemoteHostName() {
	return remoteHostName;
}
public void setRemoteHostName(String remoteHostName) {
	this.remoteHostName = remoteHostName;
}
public Calendar getReservationDetailNotifiedDate() {
	return reservationDetailNotifiedDate;
}
public void setReservationDetailNotifiedDate(
		Calendar reservationDetailNotifiedDate) {
	this.reservationDetailNotifiedDate = reservationDetailNotifiedDate;
}
public Calendar getUpdatedOn() {
	return updatedOn;
}
public void setUpdatedOn(Calendar updatedOn) {
	this.updatedOn = updatedOn;
}
public String getMasterUpdatedBy() {
	return masterUpdatedBy;
}
public void setMasterUpdatedBy(String masterUpdatedBy) {
	this.masterUpdatedBy = masterUpdatedBy;
}
public Calendar getMasterUpdatedOn() {
	return masterUpdatedOn;
}
public void setMasterUpdatedOn(Calendar masterUpdatedOn) {
	this.masterUpdatedOn = masterUpdatedOn;
}
public Calendar getReservationDetailRequestDate() {
	return reservationDetailRequestDate;
}
public void setReservationDetailRequestDate(Calendar reservationDetailRequestDate) {
	this.reservationDetailRequestDate = reservationDetailRequestDate;
}
public String getMasterInsertedBy() {
	return masterInsertedBy;
}
public void setMasterInsertedBy(String masterInsertedBy) {
	this.masterInsertedBy = masterInsertedBy;
}
public BigDecimal getReservationDetailID() {
	return reservationDetailID;
}
public void setReservationDetailID(BigDecimal reservationDetailID) {
	this.reservationDetailID = reservationDetailID;
}
public BigDecimal getReservationMasterID() {
	return reservationMasterID;
}
public void setReservationMasterID(BigDecimal reservationMasterID) {
	this.reservationMasterID = reservationMasterID;
}
public String getPoolName() {
	return poolName;
}
public void setPoolName(String poolName) {
	this.poolName = poolName;
}
public String getReservationMasterDesc() {
	return reservationMasterDesc;
}
public void setReservationMasterDesc(String reservationMasterDesc) {
	this.reservationMasterDesc = reservationMasterDesc;
}
public Calendar getTargetDeployedDate() {
	return targetDeployedDate;
}
public void setTargetDeployedDate(Calendar targetDeployedDate) {
	this.targetDeployedDate = targetDeployedDate;
}
public String getMapArraySerial() {
	return mapArraySerial;
}
public void setMapArraySerial(String mapArraySerial) {
	this.mapArraySerial = mapArraySerial;
}
public Calendar getReservationDetailFailedDate() {
	return reservationDetailFailedDate;
}
public void setReservationDetailFailedDate(Calendar reservationDetailFailedDate) {
	this.reservationDetailFailedDate = reservationDetailFailedDate;
}
public String getReservedTier() {
	return reservedTier;
}
public void setReservedTier(String reservedTier) {
	this.reservedTier = reservedTier;
}
public Calendar getReservationDetailCancelledDate() {
	return reservationDetailCancelledDate;
}
public void setReservationDetailCancelledDate(
		Calendar reservationDetailCancelledDate) {
	this.reservationDetailCancelledDate = reservationDetailCancelledDate;
}
public Calendar getReservationMasterRequestDate() {
	return reservationMasterRequestDate;
}
public void setReservationMasterRequestDate(Calendar reservationMasterRequestDate) {
	this.reservationMasterRequestDate = reservationMasterRequestDate;
}
public String getReservationType() {
	return reservationType;
}
public void setReservationType(String reservationType) {
	this.reservationType = reservationType;
}
public String getMapVolumeName() {
	return mapVolumeName;
}
public void setMapVolumeName(String mapVolumeName) {
	this.mapVolumeName = mapVolumeName;
}
public String getSubPolicyTier() {
	return subPolicyTier;
}
public void setSubPolicyTier(String subPolicyTier) {
	this.subPolicyTier = subPolicyTier;
}
public String getReservedStatus() {
	return reservedStatus;
}
public void setReservedStatus(String reservedStatus) {
	this.reservedStatus = reservedStatus;
}
public String getErrorCode() {
	return errorCode;
}
public void setErrorCode(String errorCode) {
	this.errorCode = errorCode;
}
public String getErrorMessage() {
	return errorMessage;
}
public void setErrorMessage(String errorMessage) {
	this.errorMessage = errorMessage;
}
  


public Status getStatus() {
	return status;
}
public void setStatus(Status status) {
	this.status = status;
}



@XmlTransient
private ReserveSanPoolRequest request;

public ReserveSanPoolRequest getRequest() {
	return request;
}

public void setRequest(ReserveSanPoolRequest request) {
	this.request = request;
}

  
}

