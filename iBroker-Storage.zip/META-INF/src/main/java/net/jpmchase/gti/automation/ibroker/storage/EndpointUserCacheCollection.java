package net.jpmchase.gti.automation.ibroker.storage;

import java.util.HashMap;

import org.apache.log4j.Logger;

public class EndpointUserCacheCollection 
{
  private static final Logger logger = Logger.getLogger(EndpointUserCacheCollection.class);

  private static HashMap<String, String> userCacheMap = new HashMap<String , String>();
  
  public static void cacheUser(String userID, String password)
  {
	logger.info("Caching the user=" + userID);
	userCacheMap.put(userID, password);

    logger.info("Done caching the user, size=" + userCacheMap.size());
  }
  
  public static String getPassword(String userID)
  {
	String password = userCacheMap.get(userID);
	
	logger.info("Done getting cache user password for userID=" + userID);
	return password;
  }
  
}
