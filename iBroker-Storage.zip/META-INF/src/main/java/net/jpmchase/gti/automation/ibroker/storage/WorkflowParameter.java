package net.jpmchase.gti.automation.ibroker.storage;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="workflowParameter")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowParameter")
public class WorkflowParameter 
{
  @XmlElement(name="name", required=false)  
  private String name;

  @XmlElement(name="type", required=false)  
  private String type;
  
public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getType() {
	return type;
}

public void setType(String type) {
	this.type = type;
}

  
}
