package net.jpmchase.gti.automation.ibroker.storage.client.rest.response;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect
public class FlowReference 
{
  private String href;
  private String rel;
  
  public String getHref() {
	return href;
  }

  public void setHref(String href) {
	this.href = href;
  }

  public String getRel() {
	return rel;
  }

  public void setRel(String rel) {
	this.rel = rel;
  }
}
