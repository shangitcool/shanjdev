package net.jpmchase.gti.automation.ibroker.storage.client.transformer;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.response.RunWorkflowResponse;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import org.apache.log4j.Logger;

public class ExecuteWorkflowResponseReadTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(ExecuteWorkflowResponseReadTransformer.class);
	
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {
	Object result = null;
	RunWorkflowResponse response = new RunWorkflowResponse();
	Object src = message.getPayload();
	
	logger.info("ExecuteWorkflowResponseReadTransformer received payload src=" + src);

	String successCode = message.getInvocationProperty("reserved.success");
	String errorCode = message.getInvocationProperty("reserved.failed");	
	//String noResultCode = message.getInvocationProperty("reserved.noresult");

	if (src instanceof ch.dunes.vso.webservice.WorkflowToken)
	{
	  logger.info("ExecuteWorkflowResponseReadTransformer received payload workflowtoken=" + src);
	  ch.dunes.vso.webservice.WorkflowToken workflowToken = (ch.dunes.vso.webservice.WorkflowToken)src;
  
	  if (workflowToken != null)
	  {
	  response.setId(workflowToken.getId());
	  response.setTitle(workflowToken.getTitle());
	  response.setWorkflowId(workflowToken.getWorkflowId());
	  response.setCurrentItemName(workflowToken.getCurrentItemName());
	  response.setCurrentItemState(workflowToken.getCurrentItemState());
	  response.setGlobalState(workflowToken.getGlobalState());
	  response.setBusinessState(workflowToken.getBusinessState());
	  response.setStartDate(workflowToken.getStartDate());
	  response.setEndDate(workflowToken.getEndDate());
	  response.setXmlContent(workflowToken.getXmlContent());
	  
	  String[] successMessages = successCode.split(",");
	  response.setStatus(getStatus(successMessages[0], successMessages[1]));
	  }
//	  else
//	  {
//		String[] errorMessages = noResultCode.split(",");
//		response.setStatus(getStatus(errorMessages[0], errorMessages[1]));  
//	  }
	  result = response;	  
	}
	else
	{
	  logger.error("Not a valid request..." + src);
	  String[] errorMessages = errorCode.split(",");
	  response.setStatus(getStatus(errorMessages[0], errorMessages[1]));

	  result = response;	  
	}
		
	return result;
  }

  private Status getStatus(String code, String description)
  {
	Status status = new Status();
	status.setStatusCode(code);
	status.setStatusDescription(description);
	
	return status;
  }
  
}