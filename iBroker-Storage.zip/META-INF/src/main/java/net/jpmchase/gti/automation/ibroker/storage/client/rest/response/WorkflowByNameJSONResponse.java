package net.jpmchase.gti.automation.ibroker.storage.client.rest.response;

import org.codehaus.jackson.annotate.JsonAutoDetect;

import java.util.ArrayList;

/** JSON string
{
	   "link":[
	      {
	         "attributes":[
	            {
	               "value":"https://vsin7u8606.svr.us.jpmchase.net:8281/vco/api/workflows/ba769b0d-7e8a-46e4-ad38-85647b30ff22/",
	               "name":"itemHref"
	            },
	            {
	               "value":"ba769b0d-7e8a-46e4-ad38-85647b30ff22",
	               "name":"id"
	            },
	            {
	               "value":"Get VMDK IDK and RDM UUID ",
	               "name":"categoryName"
	            },
	            {
	               "value":"true",
	               "name":"canExecute"
	            },
	            {
	               "value":"https://vsin7u8606.svr.us.jpmchase.net:8281/vco/api/catalog/System/WorkflowCategory/ff808081571f85bf01571f8a59eb1145/",
	               "name":"categoryHref"
	            },
	            {
	               "name":"description"
	            },
	            {
	               "value":"VM_Disk_Information_Query",
	               "name":"name"
	            },
	            {
	               "value":"false",
	               "name":"customIcon"
	            },
	            {
	               "value":"Workflow",
	               "name":"type"
	            },
	            {
	               "value":"false",
	               "name":"canEdit"
	            },
	            {
	               "value":"1.0.6",
	               "name":"version"
	            }
	         ],
	         "href":"https://vsin7u8606.svr.us.jpmchase.net:8281/vco/api/workflows/ba769b0d-7e8a-46e4-ad38-85647b30ff22/",
	         "rel":"down"
	      }
	   ],
	   "total":1
	}
*/

@JsonAutoDetect
public class WorkflowByNameJSONResponse
{
  private int total;
  private ArrayList<Link> link;
  
  public int getTotal() {
	return total;
  }

  public void setTotal(int total) {
	this.total = total;
  }

  public ArrayList<Link> getLink() {
	return link;
  }

  public void setLink(ArrayList<Link> link) {
	this.link = link;
  }	
}
