package net.jpmchase.gti.automation.ibroker.storage.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="workflowRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowRequest")
public class WorkflowRequest
{
  @XmlElement(name="solutionName", required=false)  
  private String solutionName; 
  @XmlElement(name="orderID", required=false)  
  private String orderID; 

  @XmlElement(name="VCOFQDN", required=true)  
  private String VCOFQDN;

//  @XmlElement(name="username", required=false)  
//  private String username;
//  @XmlElement(name="password", required=false)  
//  private String password;
  
public String getSolutionName() {
	return solutionName;
}
public void setSolutionName(String solutionName) {
	this.solutionName = solutionName;
}
public String getOrderID() {
	return orderID;
}
public void setOrderID(String orderID) {
	this.orderID = orderID;
}
public String getVCOFQDN() {
	return VCOFQDN;
}
public void setVCOFQDN(String vCOFQDN) {
	VCOFQDN = vCOFQDN;
}


  
}
