package net.jpmchase.gti.automation.ibroker.storage.request;

import net.jpmchase.gti.automation.ibroker.storage.WorkflowTokenAttribute;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="runWorkflowRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="runWorkflowRequest")
public class RunWorkflowRequest extends WorkflowByIdRequest
{
  @XmlElement(name="workflowInputs", required=false)  
  private ArrayList<WorkflowTokenAttribute> workflowInputs;  
  
public ArrayList<WorkflowTokenAttribute> getWorkflowInputs() {
	return workflowInputs;
}

public void setWorkflowInputs(ArrayList<WorkflowTokenAttribute> workflowInputs) {
	this.workflowInputs = workflowInputs;
}

  

}
