package net.jpmchase.gti.automation.ibroker.storage.client.rest.response;

import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect
public class Link 
{
  private ArrayList<NameValuePair> attributes;
  private String href;
  private String rel;
    
  public ArrayList<NameValuePair> getAttributes() {
		return attributes;
  }
  
  public void setAttributes(ArrayList<NameValuePair> attributes) {
		this.attributes = attributes;
  }
  
  public String getHref() {
		return href;  
  }
  
  public void setHref(String href) {
		this.href = href;
  }
  
  public String getRel() {
		return rel;
  }
  
  public void setRel(String rel) {
		this.rel = rel;
  }
}
