package net.jpmchase.gti.automation.ibroker.storage.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="healthCheckProperty")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="healthCheckProperty")
public class HealthCheckProperty 
{
  @XmlElement(name="name", required=false)
  private String name;
  @XmlElement(name="value", required=false)
  private String value;
  
  public String getName() {
	return name;
  }
  public void setName(String name) {
	this.name = name;
  }
  public String getValue() {
	return value;
  }
  public void setValue(String value) {
	this.value = value;
  }

  
}
