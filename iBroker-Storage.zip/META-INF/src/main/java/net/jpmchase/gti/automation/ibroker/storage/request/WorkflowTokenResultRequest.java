package net.jpmchase.gti.automation.ibroker.storage.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="workflowTokenResultRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowTokenResultRequest")
public class WorkflowTokenResultRequest extends WorkflowTokenRequest
{
}
