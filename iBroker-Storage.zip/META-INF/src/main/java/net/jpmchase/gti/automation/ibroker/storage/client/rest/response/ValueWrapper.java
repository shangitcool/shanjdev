package net.jpmchase.gti.automation.ibroker.storage.client.rest.response;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect
public class ValueWrapper 
{
  private String value;

  public String getValue() {
	return value;
  }

  public void setValue(String value) {
	this.value = value;
  }
}
