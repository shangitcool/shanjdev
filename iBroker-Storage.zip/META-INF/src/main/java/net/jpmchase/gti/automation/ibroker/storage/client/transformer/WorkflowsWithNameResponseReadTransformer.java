package net.jpmchase.gti.automation.ibroker.storage.client.transformer;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowByNameResponse;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import java.util.List;
import org.apache.log4j.Logger;

public class WorkflowsWithNameResponseReadTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowsWithNameResponseReadTransformer.class);
	
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {
	Object result = null;
	WorkflowByNameResponse response = new WorkflowByNameResponse();
	Object src = message.getPayload();
	
	logger.info("WorkflowsWithNameResponseReadTransformer received payload src=" + src);

	String successCode = message.getInvocationProperty("reserved.success");
	String errorCode = message.getInvocationProperty("reserved.failed");
	String noResultCode = message.getInvocationProperty("reserved.noresult");	

	if (src instanceof List)
	{
	  logger.info("WorkflowsWithNameResponseReadTransformer: payload instance of list=" + src);
	  List<ch.dunes.vso.webservice.Workflow> workflows = (List<ch.dunes.vso.webservice.Workflow>)src;
  
	  logger.info("WorkflowsWithNameResponseReadTransformer: checking list empty=" + workflows.isEmpty());
	  if (!workflows.isEmpty())
	  {
		ch.dunes.vso.webservice.Workflow workflow = workflows.get(0);
		response.setId(workflow.getId());
		response.setName(workflow.getName());
		response.setDescription(workflow.getDescription());
		
		//set inParameters
		//response.setInParameters();
		
		//set outParameters
		//response.setOutParameters();
		
		//set attributes
		//response.setAttributes();
		
	    String[] successMessages = successCode.split(",");
	    response.setStatus(getStatus(successMessages[0], successMessages[1]));		  
	  }
	  else
	  {	  
	    String[] errorMessages = noResultCode.split(",");
	    response.setStatus(getStatus(errorMessages[0], errorMessages[1]));
	  }
	  
	  result = response;	  
	}
	else
	{
	  logger.error("Not a valid request..." + src);
	  String[] errorMessages = errorCode.split(",");
	  response.setStatus(getStatus(errorMessages[0], errorMessages[1]));

	  result = response;	  
	}
		
	return result;
  }

  private Status getStatus(String code, String description)
  {
	Status status = new Status();
	status.setStatusCode(code);
	status.setStatusDescription(description);
	
	return status;
  }
  
}