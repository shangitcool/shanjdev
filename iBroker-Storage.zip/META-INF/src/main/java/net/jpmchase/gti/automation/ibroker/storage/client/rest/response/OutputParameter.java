package net.jpmchase.gti.automation.ibroker.storage.client.rest.response;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonAutoDetect
@JsonIgnoreProperties({"scope"})
public class OutputParameter 
{
  private String name;
  private String type;  
  private OutputValueWrapper value;
  
  public String getName() {
	return name;
  }

  public void setName(String name) {
	this.name = name;
  }

  public String getType() {
	return type;
  }

  public void setType(String type) {
	this.type = type;
  }

  public OutputValueWrapper getValue() {
	return value;
  }

  public void setValue(OutputValueWrapper value) {
	this.value = value;
  }
}
