package net.jpmchase.gti.automation.ibroker.storage.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import java.util.List;

@XmlRootElement(name="healthCheckResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="healthCheckResponse")
public class HealthCheckResponse 
{
  @XmlElement(name="HealthChecks", required=false)
  public List<HealthCheckProperty> healthChecks;

  public List<HealthCheckProperty> getHealthChecks() {
	return healthChecks;
  }

  public void setHealthChecks(List<HealthCheckProperty> healthChecks) {
	this.healthChecks = healthChecks;
  }
}
