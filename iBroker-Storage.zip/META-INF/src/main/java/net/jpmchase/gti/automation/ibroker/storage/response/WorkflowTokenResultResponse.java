package net.jpmchase.gti.automation.ibroker.storage.response;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.WorkflowTokenAttribute;
import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowTokenResultRequest;

@XmlRootElement(name="workflowTokenResultResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowTokenResultResponse")
public class WorkflowTokenResultResponse 
{
  @XmlElement(name="workflowTokenAttribute", required=false)  
  private ArrayList<WorkflowTokenAttribute> workflowTokenAttribute;
  
  @XmlElement(name="status", required=true)  
  private Status status;
  
  @XmlTransient
  private WorkflowTokenResultRequest request;
  
  
public ArrayList<WorkflowTokenAttribute> getWorkflowTokenAttribute() {
	return workflowTokenAttribute;
}

public void setWorkflowTokenAttribute(
		ArrayList<WorkflowTokenAttribute> workflowTokenAttribute) {
	this.workflowTokenAttribute = workflowTokenAttribute;
}

public Status getStatus() {
	return status;
}
public void setStatus(Status status) {
	this.status = status;
}

public WorkflowTokenResultRequest getRequest() {
	return request;
}

public void setRequest(WorkflowTokenResultRequest request) {
	this.request = request;
}



	
}
