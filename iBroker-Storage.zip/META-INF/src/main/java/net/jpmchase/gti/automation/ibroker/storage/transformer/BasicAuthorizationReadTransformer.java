package net.jpmchase.gti.automation.ibroker.storage.transformer;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;
import org.mule.api.MuleMessage;

import java.util.Map;

public class BasicAuthorizationReadTransformer extends AbstractMessageTransformer
{
  @Override
  public String transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException
  {  
	Map<String,String> httpHeaders = message.getInboundProperty("http.headers");
	String authorizationValue = "";

	for(String key: httpHeaders.keySet()) {
	  if(key.equalsIgnoreCase("authorization")) {
		authorizationValue = httpHeaders.get(key);
	 	break;
	  }
	}
	return authorizationValue;
  }
}
