package net.jpmchase.gti.automation.ibroker.storage.client.transformer;


import java.util.HashMap;

import org.apache.log4j.Logger;
import org.mule.api.MuleMessage;
import org.mule.api.transport.PropertyScope;

import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowByNameRequest;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowByNameResponse;

public class WorkflowsWithNamePayloadTransformer extends VCOPayloadTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowsWithNamePayloadTransformer.class);
	
  protected Object _process(MuleMessage message, Object src, String vcoUserName, String vcoPassword, HashMap<String, String> outboundProperties)
  {
	Object result = null;
	
	if (src instanceof WorkflowByNameResponse)
	{
	  WorkflowByNameResponse response  = (WorkflowByNameResponse)src;
	  WorkflowByNameRequest request = response.getRequest();

	  String vcoUrlValue = getVCOUrl(request.getVCOFQDN());	  
	  logger.info("VCO Instance url=" + vcoUrlValue);

	  //message.setProperty("vcoContextURL", vcoUrlValue, PropertyScope.OUTBOUND);
	  outboundProperties.put("vcoContextURL", vcoUrlValue);
	  
	  result = getPayload(request.getWorkflowName(), vcoUserName, vcoPassword);
	}	
	else
	{
	  logger.error("Not a valid request..." + src);
	}

	return result;
  }
  
  
  private Object[] getPayload(String workflowName, String vcoUserName, String vcoPassword)
  {
	logger.info("getPayload()received [workflowName= " + workflowName + ", vcoUserName=" + vcoUserName + "]");
	
	Object[] objectArray = {workflowName, vcoUserName, vcoPassword};
	return objectArray;
  }
      
}