package net.jpmchase.gti.automation.ibroker.storage.transformer;

import net.jpmchase.gti.automation.ibroker.storage.Status;

import java.util.ArrayList;
import java.util.List;

import net.jpmchase.gti.automation.ibroker.storage.response.RunWorkflowResponse;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;
import org.mule.api.MuleMessage;
//import org.mule.api.transport.PropertyScope;

import org.apache.log4j.Logger;

public class ExecuteWorkflowReadResponseTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(ExecuteWorkflowReadResponseTransformer.class);
  
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {  
	RunWorkflowResponse response = new RunWorkflowResponse();
	Object object = message.getPayload();
	
	logger.info("ExecuteWorkflowReadResponseTransformer(): payload received=" + object);
	
	String successCode = message.getInvocationProperty("reserved.success");
	String errorCode = message.getInvocationProperty("reserved.failed");
	
	String[] successMessages = successCode.split(",");
	response.setStatus(getStatus(successMessages[0], successMessages[1]));
	
	return response;
  }
  
  private Status getStatus(String code, String description)
  {
	Status status = new Status();
	status.setStatusCode(code);
	status.setStatusDescription(description);
	
	return status;
  }
}
