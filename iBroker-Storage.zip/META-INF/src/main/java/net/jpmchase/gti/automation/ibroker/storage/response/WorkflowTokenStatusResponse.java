package net.jpmchase.gti.automation.ibroker.storage.response;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowTokenStatustRequest;

@XmlRootElement(name="workflowTokenStatusResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowTokenStatusResponse")
public class WorkflowTokenStatusResponse 
{
  @XmlElement(name="returnValue", required=false)  
  private ArrayList<String> returnValues;

  @XmlElement(name="status", required=true)  
  private Status status;

  @XmlTransient
  private WorkflowTokenStatustRequest request;
  
public ArrayList<String> getReturnValues() {
	return returnValues;
}

public void setReturnValues(ArrayList<String> returnValues) {
  if (returnValues != null)
  {
	this.returnValues = returnValues;
  }
}

public Status getStatus() {
	return status;
}
public void setStatus(Status status) {
	this.status = status;
}

public WorkflowTokenStatustRequest getRequest() {
	return request;
}

public void setRequest(WorkflowTokenStatustRequest request) {
	this.request = request;
}
  

  
}
