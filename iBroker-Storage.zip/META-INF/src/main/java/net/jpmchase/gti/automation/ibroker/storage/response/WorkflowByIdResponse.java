package net.jpmchase.gti.automation.ibroker.storage.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="workflowByIdResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowByIdResponse")
public class WorkflowByIdResponse extends WorkflowResponse
{


}
