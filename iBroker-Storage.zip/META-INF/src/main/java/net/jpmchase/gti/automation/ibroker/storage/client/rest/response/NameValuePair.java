package net.jpmchase.gti.automation.ibroker.storage.client.rest.response;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect
public class NameValuePair 
{
  public String name;
  public String value;
  
  public String getName() {
	return name;
  }
  
  public void setName(String name) {
	this.name = name;
  }
  
  public String getValue() {
	return value;
  }
  
  public void setValue(String value) {
	this.value = value;
  }
}
