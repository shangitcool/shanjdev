package net.jpmchase.gti.automation.ibroker.storage.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="workflowByNameRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowByNameRequest")
public class WorkflowByNameRequest extends WorkflowRequest
{
  @XmlElement(name="workflowName", required=false)  
  private String workflowName;
  
public String getWorkflowName() {
	return workflowName;
}

public void setWorkflowName(String workflowName) {
	this.workflowName = workflowName;
} 
  
  

}
