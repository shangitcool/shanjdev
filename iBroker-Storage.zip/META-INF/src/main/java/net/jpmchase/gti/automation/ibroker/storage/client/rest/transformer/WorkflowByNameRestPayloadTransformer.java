package net.jpmchase.gti.automation.ibroker.storage.client.rest.transformer;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.WorkflowByNameJSONResponse;
import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowByNameRequest;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowByNameResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class WorkflowByNameRestPayloadTransformer  extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowByNameRestPayloadTransformer.class);
  private static final String PORT_DELIMITER = ":";
  
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {
	WorkflowByNameJSONResponse workflowByNameJSONResponse = null;
	String[] returnValues = new String[] {new String(), new String()};
	Object src = message.getPayload();
	
	logger.info("PayloadTransformer received payload src=" + src);
		
	String vcoUser = message.getInvocationProperty("app.vco.user");
	String securityURL = message.getInvocationProperty("app.security.url.v3");
	String scriptWithDir = message.getInvocationProperty("httpConnectorScript");
	
	String vcoPassword = net.jpmchase.gti.automation.ibroker.storage.EndpointUserCacheCollection.getPassword(vcoUser) ;	
	if (vcoPassword == null || vcoUser.equals(vcoPassword))
	{
	  vcoPassword = "1Crazyd2"; //_getEndpointPassword(securityURL, vcoUser);
	  net.jpmchase.gti.automation.ibroker.storage.EndpointUserCacheCollection.cacheUser(vcoUser, vcoPassword);
	}
		
	String credential = vcoUser + ":" + vcoPassword;
	String basicAuth = "" + new String(Base64.encodeBase64(credential.getBytes()));
	
	if (src instanceof WorkflowByNameResponse)
	{
	  WorkflowByNameResponse response  = (WorkflowByNameResponse)src;
	  WorkflowByNameRequest request = response.getRequest();
	  
	  String vcoHost[] = request.getVCOFQDN().split(PORT_DELIMITER);	  
	  String queryURI = "/vco/api/workflows/?conditions=name=" + request.getWorkflowName();
	  String payload = "''";	
	  String commandWithArguments = scriptWithDir + " " + basicAuth + " " 
	  				+ vcoHost[0] + " " + vcoHost[1] + " " + "GET" + " " + queryURI + " " + payload;
			
	  logger.info("transformMessage(): running commandWithArguments=" + commandWithArguments);
	  try{
	  Runtime runtime = Runtime.getRuntime();
	  Process process = runtime.exec(commandWithArguments);
	  InputStream is = process.getInputStream();
	  InputStreamReader isr = new InputStreamReader(is);
	  BufferedReader br = new BufferedReader(isr);
	  
      logger.info("transformMessage(): reading output");		
	  String line;
	  int i=0;
	  while ((line = br.readLine()) != null) {
		  returnValues[i] = line;
		  i++;
		  logger.info(line);
	  }

	  logger.info("transformMessage(): setting return values");		       
	  message.setInvocationProperty("vcoStatus", returnValues[0]);
	  message.setInvocationProperty("vcoResponse", returnValues[1]);
	  
	  workflowByNameJSONResponse = new WorkflowByNameJSONResponse();
	  ObjectMapper mapper = new ObjectMapper();
	  workflowByNameJSONResponse = mapper.readValue(returnValues[1], WorkflowByNameJSONResponse.class);
		
	  logger.info("JSON parsing is done");
		
	  }catch(Exception e){
		 logger.error(e);
	  }
	}
	
	return workflowByNameJSONResponse;
	
  }
	
    
}
