package net.jpmchase.gti.automation.ibroker.storage.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;

import net.jpmchase.gti.automation.ibroker.storage.request.RunWorkflowRequest;

@XmlRootElement(name="runWorkflowResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="runWorkflowResponse")
public class RunWorkflowResponse extends WorkflowTokenByIdResponse
{	
  @XmlTransient
  private RunWorkflowRequest request;

  public RunWorkflowRequest getRequest() {
	return request;
  }

  public void setRequest(RunWorkflowRequest request) {
	this.request = request;
  }
  
  
}
