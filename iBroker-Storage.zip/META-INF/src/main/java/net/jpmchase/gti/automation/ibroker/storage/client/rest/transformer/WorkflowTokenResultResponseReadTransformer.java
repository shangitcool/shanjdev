package net.jpmchase.gti.automation.ibroker.storage.client.rest.transformer;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.WorkflowTokenAttribute;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowTokenResultResponse;
import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.WorkflowTokenResultJSONResponse;
import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.OutputParameter;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import java.util.ArrayList;
import org.apache.log4j.Logger;

public class WorkflowTokenResultResponseReadTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowTokenResultResponseReadTransformer.class);
	
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {
	WorkflowTokenResultResponse response  = new WorkflowTokenResultResponse();
	ArrayList<WorkflowTokenAttribute> workflowTokenAttributes = new ArrayList<WorkflowTokenAttribute>();
	boolean checkSuccessReturnCode = false;
	boolean checkRetryReturnCode = false;
	Object src = message.getPayload();
	
	logger.info("WorkflowTokenResultResponseReadTransformer received payload src=" + src);

	String successCode = message.getInvocationProperty("reserved.success");
	String retryCode = message.getInvocationProperty("reserved.retry");
	String errorCode = message.getInvocationProperty("reserved.failed");	
	String noResultCode = message.getInvocationProperty("reserved.noresult");
	String tokenPropertyName = message.getInvocationProperty("token.property.name");
	String successTokenPropertyPattern = message.getInvocationProperty("success.token.property.pattern");
	String retryTokenPropertyPattern = message.getInvocationProperty("retry.token.property.pattern");
	
	response.setStatus(getStatus(errorCode)); //assuming not-a-valid request
	if (src instanceof WorkflowTokenResultJSONResponse)
	{
	  WorkflowTokenResultJSONResponse workflowTokenResultJSONResponse = (WorkflowTokenResultJSONResponse)src;
  
	  response.setStatus(getStatus(noResultCode)); //assuming no-result from VCO
	  if (workflowTokenResultJSONResponse != null)
	  {
		for(OutputParameter outputParameter : workflowTokenResultJSONResponse.getOutputparameters()){
		  WorkflowTokenAttribute attribute = new WorkflowTokenAttribute();
		  workflowTokenAttributes.add(attribute);
		  
		  attribute.setName(outputParameter.getName());
		  attribute.setType(outputParameter.getType());
		  if (outputParameter.getValue() != null && outputParameter.getValue().getString() != null){
		    attribute.setValue(outputParameter.getValue().getString().getValue());
		  } else if (outputParameter.getValue() != null && outputParameter.getValue().getNumber() != null){
			attribute.setValue(outputParameter.getValue().getNumber().getValue());  
		  }
		  
		  if (attribute.getName().equalsIgnoreCase(tokenPropertyName)){
	    	logger.info("WorkflowTokenResultResponseReadTransformer: tokenProperty=" + attribute.getValue());
	    	logger.info("WorkflowTokenResultResponseReadTransformer: retryTokenPropertyPattern=" + retryTokenPropertyPattern);
	    	logger.info("WorkflowTokenResultResponseReadTransformer: successTokenPropertyPattern=" + successTokenPropertyPattern);
	    	if (attribute.getValue().matches(successTokenPropertyPattern)){
	    		checkSuccessReturnCode = true;
	    		logger.info("WorkflowTokenResultResponseReadTransformer: workflow executed successfully, ibroker returns success=" + checkSuccessReturnCode);
	    	} else if (attribute.getValue().matches(retryTokenPropertyPattern)){
	    		checkRetryReturnCode = true;
	    		logger.info("WorkflowTokenResultResponseReadTransformer: workflow retry mode, ibroker returns retry=" + checkRetryReturnCode);
	    	} else {	  
	    		logger.info(
	    		"WorkflowTokenResultResponseReadTransformer: workflow token property pattern not matching, ibroker returns failure["
	    		+ checkRetryReturnCode + "," + checkSuccessReturnCode + "]");
	    	}
		  }
		  
		}
		 
		response.setWorkflowTokenAttribute(workflowTokenAttributes);
		
	    if (checkSuccessReturnCode){
		   response.setStatus(getStatus(successCode));	    	 
		}
		else if (checkRetryReturnCode){
		   response.setStatus(getStatus(retryCode));	    	 
		}
		logger.info("start-date=" + workflowTokenResultJSONResponse.getStartdate());
		logger.info("end-date=" + workflowTokenResultJSONResponse.getEnddate());
	  }
	  
	}

	return response;
  }

  private Status getStatus(String messageCode)
  {
	String[] messages = messageCode.split(",");
	
	Status status = new Status();
	status.setStatusCode(messages[0]);
	status.setStatusDescription(messages[1]);
	
	return status;
  }
  
}