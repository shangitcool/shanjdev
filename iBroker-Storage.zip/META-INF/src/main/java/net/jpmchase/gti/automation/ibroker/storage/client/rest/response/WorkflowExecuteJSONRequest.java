package net.jpmchase.gti.automation.ibroker.storage.client.rest.response;

import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonProperty;

@JsonAutoDetect
public class WorkflowExecuteJSONRequest 
{
  @JsonProperty("parameters")
  private ArrayList<OutputParameter> parameters;

  public ArrayList<OutputParameter> getParameters() {
	return parameters;
  }

  public void setParameters(ArrayList<OutputParameter> parameters) {
	this.parameters = parameters;
  }
}
