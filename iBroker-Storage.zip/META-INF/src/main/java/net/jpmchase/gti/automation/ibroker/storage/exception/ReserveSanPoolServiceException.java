package net.jpmchase.gti.automation.ibroker.storage.exception;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.response.ReserveSanPoolResponse;

import org.apache.log4j.Logger;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class ReserveSanPoolServiceException extends AbstractMessageTransformer
{
   private static final Logger logger = Logger.getLogger(ReserveSanPoolServiceException.class);
	
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)  
	throws TransformerException 
  {
	ReserveSanPoolResponse response = new ReserveSanPoolResponse();	
	Object object = message.getPayload();
		
	logger.error("An error occurred:" + object);
	String errorCode = message.getInvocationProperty("errorCode");
		
	String[] errors = errorCode.split(",");
	Status status = new Status();
	status.setStatusCode(errors[0]);
	status.setStatusDescription(errors[1] + "," + ((Exception)object).toString());	
		
	response.setStatus(status);		
	return response;
  }
}
