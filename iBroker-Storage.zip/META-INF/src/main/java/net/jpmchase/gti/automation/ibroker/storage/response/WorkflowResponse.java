package net.jpmchase.gti.automation.ibroker.storage.response;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.WorkflowParameter;

@XmlRootElement(name="workflowResponse")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowResponse")
public class WorkflowResponse 
{
  @XmlElement(name="id", required=false)  
  private String id;

  @XmlElement(name="name", required=false)  
  private String name;

  @XmlElement(name="description", required=false)  
  private String description;

  @XmlElement(name="inParameters", required=false)  
  private ArrayList<WorkflowParameter> inParameters;

  @XmlElement(name="outParameters", required=false)  
  private ArrayList<WorkflowParameter> outParameters;

  @XmlElement(name="attributes", required=false)  
  private ArrayList<WorkflowParameter> attributes;
  
  @XmlElement(name="status", required=true)  
  private Status status;

  
public String getId() {
	return id;
}

public void setId(String id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public ArrayList<WorkflowParameter> getInParameters() {
	return inParameters;
}

public void setInParameters(ArrayList<WorkflowParameter> inParameters) {
	this.inParameters = inParameters;
}

public ArrayList<WorkflowParameter> getOutParameters() {
	return outParameters;
}

public void setOutParameters(ArrayList<WorkflowParameter> outParameters) {
	this.outParameters = outParameters;
}

public ArrayList<WorkflowParameter> getAttributes() {
	return attributes;
}

public void setAttributes(ArrayList<WorkflowParameter> attributes) {
	this.attributes = attributes;
}

public Status getStatus() {
	return status;
}
public void setStatus(Status status) {
	this.status = status;
}

  
}
