package net.jpmchase.gti.automation.ibroker.storage.client.transformer;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowTokenStatusResponse;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

public class WorkflowTokenStatusResponseReadTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowTokenStatusResponseReadTransformer.class);
	
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {
	Object result = null;
	WorkflowTokenStatusResponse response  = new WorkflowTokenStatusResponse();
	Object src = message.getPayload();
	
	logger.info("WorkflowTokenStatusResponseReadTransformer received payload src=" + src);

	String successCode = message.getInvocationProperty("reserved.success");
	String errorCode = message.getInvocationProperty("reserved.failed");	
	String noResultCode = message.getInvocationProperty("reserved.noresult");

	if (src instanceof List)
	{
	  logger.info("WorkflowTokenStatusResponseReadTransformer: payload list instance=" + src);
	  ArrayList<String> tokenStatusList = (ArrayList<String>)src;
  
	  logger.info("WorkflowTokenStatusResponseReadTransformer: list empty=" + tokenStatusList.isEmpty());
	  if (!tokenStatusList.isEmpty() && !isContainsOnly("null", tokenStatusList))
	  {
		logger.info("WorkflowTokenStatusResponseReadTransformer: list=" + tokenStatusList);
		for (String value : tokenStatusList)
		{
		  logger.info("WorkflowTokenStatusResponseReadTransformer: list value=" + value);
		}
		response.setReturnValues(tokenStatusList);
	    String[] successMessages = successCode.split(",");
	    response.setStatus(getStatus(successMessages[0], successMessages[1]));
	  }
	  else
	  {
		String[] errorMessages = noResultCode.split(",");
		response.setStatus(getStatus(errorMessages[0], errorMessages[1]));  
	  }
	  
	  result = response;	  
	}
	else
	{
	  logger.error("Not a valid request..." + src);
	  String[] errorMessages = errorCode.split(",");
	  response.setStatus(getStatus(errorMessages[0], errorMessages[1]));

	  result = response;	  
	}
		
	return result;
  }

  private boolean isContainsOnly(String onlyValue, ArrayList<String> listValue)
  {
	boolean result = true;
	int count = 0;
	
	if (listValue != null){
	  for (String value: listValue){
	     if (value == null || onlyValue.equalsIgnoreCase(value)){
		   count++;
	     }
	  }
	  
	  result = count!=listValue.size()?false:true;
	}
	
	return result;
  }
  
  private Status getStatus(String code, String description)
  {
	Status status = new Status();
	status.setStatusCode(code);
	status.setStatusDescription(description);
	
	return status;
  }
  
}