package net.jpmchase.gti.automation.ibroker.storage.request;

import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="reserveSanRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="reserveSanRequest")
public class ReserveSanRequest 
{	
  @XmlElement(name="solutionName", required=false)  
  private String solutionName; 
  @XmlElement(name="orderID", required=false)  
  private String orderID; 
  @XmlElement(name="requestID", required=false)  
  private String requestID;
  @XmlElement(name="systemID", required=true)  
  private String systemID;
  @XmlElement(name="primeID", required=true)  
  private String primeID;
  @XmlElement(name="hostName", required=true)  
  private String hostName;
  @XmlElement(name="deviceID", required=true)  
  private String deviceID;

  public String getSolutionName() {
	return solutionName;
  }
  public void setSolutionName(String solutionName) {
	this.solutionName = solutionName;
  }
  public String getOrderID() {
	return orderID;
  }
  public void setOrderID(String orderID) {
	this.orderID = orderID;
  }
  public String getRequestID() {
	return requestID;
  }
  public void setRequestID(String requestID) {
	this.requestID = requestID;
  }
  public String getSystemID() {
	return systemID;
  }
  public void setSystemID(String systemID) {
	this.systemID = systemID;
  }
  public String getPrimeID() {
	return primeID;
  }
  public void setPrimeID(String primeID) {
	this.primeID = primeID;
  }
  public String getHostName() {
	return hostName;
  }
  public void setHostName(String hostName) {
	this.hostName = hostName;
  }
  public String getDeviceID() {
	return deviceID;
  }
  public void setDeviceID(String deviceID) {
	this.deviceID = deviceID;
  } 
  
}
