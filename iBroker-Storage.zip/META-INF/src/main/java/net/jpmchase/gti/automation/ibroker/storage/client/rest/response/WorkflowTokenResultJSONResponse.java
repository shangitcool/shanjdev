package net.jpmchase.gti.automation.ibroker.storage.client.rest.response;

import java.util.ArrayList;

import org.codehaus.jackson.annotate.JsonAutoDetect;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonSetter;

/** JSON string 
{
	   "relations":{
	      "link":[
	         {
	            "href":"https://vsin21p1918.svr.us.jpmchase.net:8281/vco/api/workflows/ba769b0d-7e8a-46e4-ad38-85647b30ff22/executions/",
	            "rel":"up"
	         },
	         {
	            "href":"https://vsin21p1918.svr.us.jpmchase.net:8281/vco/api/workflows/ba769b0d-7e8a-46e4-ad38-85647b30ff22/executions/ff808081571099a1015752a8b5840f28/",
	            "rel":"remove"
	         },
	         {
	            "href":"https://vsin21p1918.svr.us.jpmchase.net:8281/vco/api/workflows/ba769b0d-7e8a-46e4-ad38-85647b30ff22/executions/ff808081571099a1015752a8b5840f28/logs/",
	            "rel":"logs"
	         },
	         {
	            "href":"https://vsin21p1918.svr.us.jpmchase.net:8281/vco/api/workflows/ba769b0d-7e8a-46e4-ad38-85647b30ff22/executions/ff808081571099a1015752a8b5840f28/state/",
	            "rel":"state"
	         }
	      ]
	   },
	   "id":"ff808081571099a1015752a8b5840f28",
	   "state":"completed",
	   "name":"VM_Disk_Information_Query",
	   "href":"https://vsin21p1918.svr.us.jpmchase.net:8281/vco/api/workflows/ba769b0d-7e8a-46e4-ad38-85647b30ff22/executions/ff808081571099a1015752a8b5840f28/",
	   "start-date":1474560570756,
	   "end-date":1474560581882,
	   "started-by":"E712751@NAEAST.AD.JPMORGANCHASE.COM",
	   "input-parameters":[
	      {
	         "value":{
	            "string":{
	               "value":"iaasn00006905"
	            }
	         },
	         "type":"string",
	         "name":"virtualMachine_1",
	         "scope":"local"
	      },
	      {
	         "value":{
	            "string":{
	               "value":"138759.1.cce68c3d-1f28-44bd-a583-b6386668415e 138759.2.6f1b9e42-fba2-46ab-e7eb-b2591539165c 138759.3.4a9c0cdb-12a2-4f33-c3e8-9bebb2d578ce"
	            }
	         },
	         "type":"string",
	         "name":"myComputeID_1",
	         "scope":"local"
	      }
	   ],
	   "output-parameters":[
	      {
	         "value":{
	            "string":{
	               "value":"138759.2.6f1b9e42-fba2-46ab-e7eb-b2591539165c 6000C29a-6202-6cfd-fddb-03ae450fc0a1"
	            }
	         },
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_1",
	         "scope":"local"
	      },
	      {
	         "value":{
	            "string":{
	               "value":"138759.3.4a9c0cdb-12a2-4f33-c3e8-9bebb2d578ce 6000C298-42e3-a9be-b37c-e7db602af014"
	            }
	         },
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_2",
	         "scope":"local"
	      },
	      {
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_3",
	         "scope":"local"
	      },
	      {
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_4",
	         "scope":"local"
	      },
	      {
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_5",
	         "scope":"local"
	      },
	      {
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_6",
	         "scope":"local"
	      },
	      {
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_7",
	         "scope":"local"
	      },
	      {
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_8",
	         "scope":"local"
	      },
	      {
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_9",
	         "scope":"local"
	      },
	      {
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_10",
	         "scope":"local"
	      },
	      {
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_11",
	         "scope":"local"
	      },
	      {
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_12",
	         "scope":"local"
	      },
	      {
	         "value":{
	            "number":{
	               "value":0.0
	            }
	         },
	         "type":"number",
	         "name":"ReturnCode",
	         "scope":"local"
	      },
	      {
	         "value":{
	            "string":{
	               "value":"Workflow Completed"
	            }
	         },
	         "type":"string",
	         "name":"ReturnResponse",
	         "scope":"local"
	      },
	      {
	         "value":{
	            "string":{
	               "value":"138759.1.cce68c3d-1f28-44bd-a583-b6386668415e 6000C297-0f2a-1c93-40b8-88e6b14402cd"
	            }
	         },
	         "type":"string",
	         "name":"vmwareUUID_myComputeID_0",
	         "scope":"local"
	      }
	   ]
	}
*/

@JsonAutoDetect
@JsonIgnoreProperties({"input-parameters"})
public class WorkflowTokenResultJSONResponse 
{
  private Relations relations;
  private String id; 		//workflow tokenID
  private String state; 	//workflow token status
  private String name; 		//workflow name
  private String href;
  
  @JsonProperty("start-date")
  private long startdate;
  
  @JsonProperty("end-date")
  private long enddate;
  
  @JsonProperty("started-by")
  private String startedby;
  
  @JsonProperty("input-parameters")
  private Object inputparameters;
  
  @JsonProperty("output-parameters")
  private ArrayList<OutputParameter> outputparameters;
  
  public Relations getRelations() {
	return relations;
  }

  public void setRelations(Relations relations) {
	this.relations = relations;
  }

  public String getId() {
	return id;
  }

  public void setId(String id) {
	this.id = id;
  }

  public String getState() {
	return state;
  }

  public void setState(String state) {
	this.state = state;
  }

  public String getName() {
	return name;
  }

  public void setName(String name) {
	this.name = name;
  }

  public String getHref() {
	return href;
  }

  public void setHref(String href) {
	this.href = href;
  }

  public long getStartdate() {
	return startdate;
  }
  
  @JsonSetter("start-date")
  public void setStartdate(long startdate) {
	this.startdate = startdate;
  }

  public long getEnddate() {
	return enddate;
  }

  @JsonSetter("end-date")
  public void setEnddate(long enddate) {
	this.enddate = enddate;
  }

  public String getStartedby() {
	return startedby;
  }

  @JsonSetter("started-by")
  public void setStartedby(String startedby) {
	this.startedby = startedby;
  }

  public Object getInputparameters() {
	return inputparameters;
  }

  @JsonSetter("input-parameters")
  public void setInputparameters(Object inputparameters) {
	this.inputparameters = inputparameters;
  }

  public ArrayList<OutputParameter> getOutputparameters() {
	return outputparameters;
  }

  @JsonSetter("output-parameters")
  public void setOutputparameters(ArrayList<OutputParameter> outputparameters) {
	this.outputparameters = outputparameters;
  }
}
