package net.jpmchase.gti.automation.ibroker.storage;

import javax.xml.bind.annotation.XmlElement;

public class WorkflowTokenAttribute extends WorkflowParameter
{
  @XmlElement(name="value", required=false)  
  private String value;
  
public String getValue() {
	return value;
}

public void setValue(String value) {
	this.value = value;
}
  
  

}
