package net.jpmchase.gti.automation.ibroker.storage.client.transformer;

import org.apache.log4j.Logger;
import org.mule.api.MuleMessage;
import org.mule.api.transport.PropertyScope;

import java.util.ArrayList;
import java.util.HashMap;

import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowTokenStatustRequest;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowTokenStatusResponse;

public class WorkflowTokenStatusPayloadTransformer extends VCOPayloadTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowTokenStatusPayloadTransformer.class);
	
  protected Object _process(MuleMessage message, Object src, String vcoUserName, String vcoPassword, HashMap<String, String> outboundProperties)
  {
	Object result = null;
	
	if (src instanceof WorkflowTokenStatusResponse)
	{
	  WorkflowTokenStatusResponse response  = (WorkflowTokenStatusResponse)src;
	  WorkflowTokenStatustRequest request = response.getRequest();

	  String vcoUrlValue = getVCOUrl(request.getVCOFQDN());	  
	  logger.info("VCO Instance url=" + vcoUrlValue);
	  
	  //message.setInvocationProperty("vcoContextURL", vcoUrlValue);
	  //message.setProperty("vcoContextURL", vcoUrlValue, PropertyScope.OUTBOUND);
	  
	  outboundProperties.put("vcoContextURL", vcoUrlValue);
	  
	  result = getPayload(request.getWorkflowTokenIds(), vcoUserName, vcoPassword);
	}	
	else
	{
	  logger.error("Not a valid request..." + src);
	}

	return result;
  }
  
  
  private Object[] getPayload(ArrayList<String> workflowTokenIds, String vcoUserName, String vcoPassword)
  {
	logger.info("getPayload()received [workflowToekn size= " + workflowTokenIds.size() + ", vcoUserName=" + vcoUserName + "]");
	
	Object[] objectArray = {workflowTokenIds, vcoUserName, vcoPassword};
	return objectArray;
  }
      
}