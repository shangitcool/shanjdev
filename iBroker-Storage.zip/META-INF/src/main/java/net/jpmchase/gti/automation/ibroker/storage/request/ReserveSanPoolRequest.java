package net.jpmchase.gti.automation.ibroker.storage.request;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="reserveSanPoolRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="reserveSanPoolRequest")
public class ReserveSanPoolRequest 
{
  @XmlElement(name="solutionName", required=false)  
  private String solutionName; 
  @XmlElement(name="orderID", required=false)  
  private String orderID; 
  @XmlElement(name="requestID", required=false)  
  private String requestID;
  @XmlElement(name="systemID", required=true)  
  private String systemID;
  @XmlElement(name="site", required=false)  
  private String site;
  @XmlElement(name="fabric", required=false)  
  private String fabric;
  @XmlElement(name="tier", required=false)  
  private String tier;
  @XmlElement(name="purpose", required=false)  
  private String purpose;
  @XmlElement(name="array", required=false)  
  private String array;
  @XmlElement(name="pool", required=false)  
  private String pool;
  @XmlElement(name="hostName", required=false)  
  private String hostName;
  @XmlElement(name="deploymentDate", required=false)  
  private String deploymentDate;
  @XmlElement(name="volumeName", required=false)  
  private String volumeName;
  @XmlElement(name="capacity", required=false)  
  private BigDecimal capacity;
  @XmlElement(name="policysTier", required=false)  
  private String policysTier;
  @XmlElement(name="reservationDesc", required=false)  
  private String reservationDesc;
  @XmlElement(name="reservationType", required=false)  
  private String reservationType;
  @XmlElement(name="source", required=false)  
  private String source;
  @XmlElement(name="lob", required=false)  
  private String lob;  
  @XmlElement(name="primeID", required=true)  
  private String primeID;
  @XmlElement(name="deviceID", required=true)  
  private String deviceID;
  @XmlElement(name="user", required=false)  
  private String user;  
  @XmlElement(name="userEmail", required=false)  
  private String userEmail;  
  @XmlElement(name="managerSID", required=false)  
  private String managerSID;    
  @XmlElement(name="managerEmail", required=false)  
  private String managerEmail;
  
  public String getSolutionName() {
	return solutionName;
  }
  public void setSolutionName(String solutionName) {
	this.solutionName = solutionName;
  }
  public String getOrderID() {
	return orderID;
  }
  public void setOrderID(String orderID) {
	this.orderID = orderID;
  }
  public String getRequestID() {
	return requestID;
  }
  public void setRequestID(String requestID) {
	this.requestID = requestID;
  }
  public String getSystemID() {
	return systemID;
  }
  public void setSystemID(String systemID) {
	this.systemID = systemID;
  }
  public String getSite() {
	return site;
  }
  public void setSite(String site) {
	this.site = site;
  }
  public String getFabric() {
	return fabric;
  }
  public void setFabric(String fabric) {
	this.fabric = fabric;
  }
  public String getTier() {
	return tier;
  }
  public void setTier(String tier) {
	this.tier = tier;
  }
  public String getPurpose() {
	return purpose;
  }
  public void setPurpose(String purpose) {
	this.purpose = purpose;
  }
  public String getArray() {
	return array;
  }
  public void setArray(String array) {
	this.array = array;
  }
  public String getPool() {
	return pool;
  }
  public void setPool(String pool) {
	this.pool = pool;
  }
  public String getHostName() {
	return hostName;
  }
  public void setHostName(String hostName) {
	this.hostName = hostName;
  }
  public String getDeploymentDate() {
	return deploymentDate;
  }
  public void setDeploymentDate(String deploymentDate) {
	this.deploymentDate = deploymentDate;
  }
  public String getVolumeName() {
	return volumeName;
  }
  public void setVolumeName(String volumeName) {
	this.volumeName = volumeName;
  }
  public BigDecimal getCapacity() {
	return capacity;
  }
  public void setCapacity(BigDecimal capacity) {
	this.capacity = capacity;
  }
  public String getPolicysTier() {
	return policysTier;
  }
  public void setPolicysTier(String policysTier) {
	this.policysTier = policysTier;
  }
  public String getReservationDesc() {
	return reservationDesc;
  }
  public void setReservationDesc(String reservationDesc) {
	this.reservationDesc = reservationDesc;
  }
  public String getReservationType() {
	return reservationType;
  }
  public void setReservationType(String reservationType) {
	this.reservationType = reservationType;
  }
  public String getSource() {
	return source;
  }
  public void setSource(String source) {
	this.source = source;
  }
  public String getLob() {
	return lob;
  }
  public void setLob(String lob) {
	this.lob = lob;
  }
  public String getPrimeID() {
	return primeID;
  }
  public void setPrimeID(String primeID) {
	this.primeID = primeID;
  }
  public String getDeviceID() {
	return deviceID;
  }
  public void setDeviceID(String deviceID) {
	this.deviceID = deviceID;
  }
  public String getUser() {
	return user;
  }
  public void setUser(String user) {
	this.user = user;
  }
  public String getUserEmail() {
	return userEmail;
  }
  public void setUserEmail(String userEmail) {
	this.userEmail = userEmail;
  }
  public String getManagerSID() {
	return managerSID;
  }
  public void setManagerSID(String managerSID) {
	this.managerSID = managerSID;
  }
  public String getManagerEmail() {
	return managerEmail;
  }
  public void setManagerEmail(String managerEmail) {
	this.managerEmail = managerEmail;
  }  
    
}
