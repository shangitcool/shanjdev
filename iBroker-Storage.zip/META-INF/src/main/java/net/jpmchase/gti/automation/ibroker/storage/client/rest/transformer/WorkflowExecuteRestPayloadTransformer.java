package net.jpmchase.gti.automation.ibroker.storage.client.rest.transformer;


import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import net.jpmchase.gti.automation.ibroker.storage.WorkflowTokenAttribute;
import net.jpmchase.gti.automation.ibroker.storage.request.RunWorkflowRequest;
import net.jpmchase.gti.automation.ibroker.storage.response.RunWorkflowResponse;
import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.OutputParameter;
import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.OutputValueWrapper;
import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.ValueWrapper;
import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.WorkflowExecuteJSONRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class WorkflowExecuteRestPayloadTransformer  extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowExecuteRestPayloadTransformer.class);
  private static final String PORT_DELIMITER = ":";
  
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {
	Object src = message.getPayload();
	String[] returnValues = new String[] {new String(), new String()};
	
	logger.info("PayloadTransformer received payload src=" + src);
		
	String vcoUser = message.getInvocationProperty("app.vco.user");
	String securityURL = message.getInvocationProperty("app.security.url.v3");
	String scriptWithDir = message.getInvocationProperty("httpConnectorScript");
	
	String vcoPassword = net.jpmchase.gti.automation.ibroker.storage.EndpointUserCacheCollection.getPassword(vcoUser) ;	
	if (vcoPassword == null || vcoUser.equals(vcoPassword))
	{
	  vcoPassword = "1Crazyd2"; //_getEndpointPassword(securityURL, vcoUser);
	  net.jpmchase.gti.automation.ibroker.storage.EndpointUserCacheCollection.cacheUser(vcoUser, vcoPassword);
	}
		
	String credential = vcoUser + ":" + vcoPassword;
	String basicAuth = "" + new String(Base64.encodeBase64(credential.getBytes()));
	
	if (src instanceof RunWorkflowResponse)
	{	  
	  RunWorkflowResponse response  = (RunWorkflowResponse)src;
	  RunWorkflowRequest request = response.getRequest();
	  
	  String vcoHost[] = request.getVCOFQDN().split(PORT_DELIMITER);
	  String queryURI = "/vco/api/workflows/" + request.getWorkflowId() + "/executions"; 
	  
	  //String queryURI = "/vco/api/workflows/ba769b0d-7e8a-46e4-ad38-85647b30ff22/executions/"; //+request.getWorkflowId()
	  //String queryURI = "/vco/api/workflows/{workflowid}/executions/" + request.getWorkflowTokenIds().get(0);
	  
	  WorkflowExecuteJSONRequest jsonRequest = new WorkflowExecuteJSONRequest();
	  ArrayList<OutputParameter> parameters = new ArrayList<OutputParameter>();
	  
	  for (WorkflowTokenAttribute tokenAttribute : request.getWorkflowInputs()){
		  
		  OutputValueWrapper wrapperValue = new OutputValueWrapper();
		  if ("string".equalsIgnoreCase(tokenAttribute.getType())){
			ValueWrapper string = new ValueWrapper();
			string.setValue(tokenAttribute.getValue());
			wrapperValue.setString(string);
		  } else if ("number".equalsIgnoreCase(tokenAttribute.getType())){
			ValueWrapper number = new ValueWrapper();
			number.setValue(tokenAttribute.getValue());
			wrapperValue.setNumber(number);
		  }
		  
		  OutputParameter parameter = new OutputParameter();
		  parameter.setName(tokenAttribute.getName());
		  parameter.setType(tokenAttribute.getType());
		  parameter.setValue(wrapperValue);
		  
		  parameters.add(parameter);
	  }

	  jsonRequest.setParameters(parameters);
	  
	  try{
	  ObjectMapper mapper = new ObjectMapper();
	  String payload = mapper.writeValueAsString(jsonRequest);
	  
	  String commandWithArguments = scriptWithDir + " " + basicAuth + " " 
	  				+ vcoHost[0] + " " + vcoHost[1] + " " + "POST" + " " + queryURI + " " + payload;
			
	  logger.info("transformMessage(): running commandWithArguments=" + commandWithArguments);
	  
	  Runtime runtime = Runtime.getRuntime();
	  Process process = runtime.exec(commandWithArguments);
	  InputStream is = process.getInputStream();
	  InputStreamReader isr = new InputStreamReader(is);
	  BufferedReader br = new BufferedReader(isr);
	  
      logger.info("transformMessage(): reading output");		
	  String line;
	  int i=0;
	  while ((line = br.readLine()) != null) {
		  returnValues[i] = line;
		  i++;
		  logger.info(line);
	  }

	  logger.info("transformMessage(): setting return values:" + returnValues[1]);		       
	  message.setInvocationProperty("vcoStatus", returnValues[0]);
	  message.setInvocationProperty("vcoResponse", returnValues[1]);
		
		
	  }catch(Exception e){
		 logger.error(e);
	  }
	}
	
	return null;	
  }    
}

