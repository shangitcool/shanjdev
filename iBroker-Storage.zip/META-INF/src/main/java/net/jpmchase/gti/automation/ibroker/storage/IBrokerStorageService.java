package net.jpmchase.gti.automation.ibroker.storage;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;

import net.jpmchase.gti.automation.ibroker.storage.request.ReserveSanPoolRequest;
import net.jpmchase.gti.automation.ibroker.storage.request.ReserveSanRequest;
import net.jpmchase.gti.automation.ibroker.storage.request.RunWorkflowRequest;

//import net.jpmchase.gti.automation.ibroker.storage.request.StorageDeviceRequest;
//import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowByIdRequest;
//import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowTokenByIdRequest;

import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowByNameRequest;
import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowTokenResultRequest;
import net.jpmchase.gti.automation.ibroker.storage.request.WorkflowTokenStatustRequest;
import net.jpmchase.gti.automation.ibroker.storage.response.ReserveSanPoolResponse;
import net.jpmchase.gti.automation.ibroker.storage.response.ReserveSanResponse;
import net.jpmchase.gti.automation.ibroker.storage.response.PingResponse;
import net.jpmchase.gti.automation.ibroker.storage.response.HealthCheckResponse;
import net.jpmchase.gti.automation.ibroker.storage.response.RunWorkflowResponse;

//import net.jpmchase.gti.automation.ibroker.storage.response.StorageDeviceResponse;
//import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowByIdResponse;
//import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowTokenByIdResponse;

import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowByNameResponse;

import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowTokenResultResponse;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowTokenStatusResponse;

import org.apache.log4j.Logger;

@WebService
public class IBrokerStorageService 
{
  private static final Logger logger = Logger.getLogger(IBrokerStorageService.class);
  
  @WebMethod
  @WebResult(name="reserveSanResponse")
  public ReserveSanResponse readSanReservation(
		  @WebParam(name="reserveSanRequest")ReserveSanRequest request)
  {	
	logger.debug("Starting readSanReservation()");

	ReserveSanResponse response = new ReserveSanResponse();
	response.setRequest(request);	

	logger.info("readSanReservation[solutionName=" + request.getSolutionName() +
								",orderID=" + request.getOrderID() +
								",primeID=" + request.getPrimeID() +
								"]");
	
	logger.debug("Done readSanReservation()");
	return response;
  }

  @WebMethod
  @WebResult(name="reserveSanPoolResponse")
  public ReserveSanPoolResponse createSanPoolReservation(
		  @WebParam(name="reserveSanPoolRequest")ReserveSanPoolRequest request)
  {	
	logger.debug("Starting createSanPoolReservation()");	
	ReserveSanPoolResponse response = new ReserveSanPoolResponse();
	response.setRequest(request);
	
	logger.info("createSanPoolReservation[solutionName=" + request.getSolutionName() +
								",orderID=" + request.getOrderID() +
								"]");
	
	logger.debug("Done createSanPoolReservation()");
	return response;
  }

//  @WebMethod
//  @WebResult(name="storageDeviceResponse")
//  public StorageDeviceResponse readStorageDeviceData(@WebParam(name="storageDeviceRequest")StorageDeviceRequest request)
//  {
//	StorageDeviceResponse response = new StorageDeviceResponse();
//	response.setVMDiskUUID("964ac7a5d3656c5762520683d318f9e8e48e4ed69b21e82bb91f2f726e88f154");
//	response.setSCSIID("318f9e8e48e");
//	response.setDiskName("Disk00101010");
//	response.setNAAID("7a5d36101011f2");
//	
//	Status status = new Status();
//	status.setStatusCode("IS001");
//	status.setStatusDescription("Request processed successfully!!!");
//	
//	response.setStatus(status);
//	
//	return response;  
//  }

  @WebMethod
  @WebResult(name="workflowByNameResponse")
  public WorkflowByNameResponse readWorkflowsByName(@WebParam(name="workflowByNameRequest")WorkflowByNameRequest request)
  {
	WorkflowByNameResponse response = new WorkflowByNameResponse();
	response.setRequest(request);
	
	//consumes getWorkflowsWithName()
	logger.info("readWorkflowsByName[solutionName=" + request.getSolutionName() +
			",orderID=" + request.getOrderID() + ",VCO Instance=" + request.getVCOFQDN() + 
			"]");

	return response;  
  }
  
//  @WebMethod
//  @WebResult(name="workflowByIdResponse")
//  public WorkflowByIdResponse readWorkflowForId(@WebParam(name="workflowByIdRequest")WorkflowByIdRequest request)
//  {
//	 WorkflowByIdResponse response = new WorkflowByIdResponse();	 
//	
//	//consumes getWorkflowForId()
//	Status status = new Status();
//	status.setStatusCode("IS001");
//	status.setStatusDescription("Request processed successfully!!!");
//		
//	response.setStatus(status);
//
//	return response;  
//  }
  
  @WebMethod
  @WebResult(name="workflowTokenResultResponse")
  public WorkflowTokenResultResponse readWorkflowTokenResult(@WebParam(name="workflowTokenResultRequest")WorkflowTokenResultRequest request)
  {
	WorkflowTokenResultResponse response = new WorkflowTokenResultResponse();	 
	response.setRequest(request);
	
	//consumes getWorkflowTokenResult()
	logger.info("readWorkflowTokenResult[solutionName=" + request.getSolutionName() +
			",orderID=" + request.getOrderID() + ",VCO Instance=" + request.getVCOFQDN() + 
			"]");

	return response;  
  }
  
  @WebMethod
  @WebResult(name="workflowTokenStatusResponse")
  public WorkflowTokenStatusResponse readWorkflowTokenStatus(@WebParam(name="workflowTokenStatusRequest")WorkflowTokenStatustRequest request)
  {
	WorkflowTokenStatusResponse response = new WorkflowTokenStatusResponse();	 
	response.setRequest(request);
	
	//consumes getWorkflowTokenStatus()
	logger.info("readWorkflowTokenStatus[solutionName=" + request.getSolutionName() +
			",orderID=" + request.getOrderID() + ",VCO Instance=" + request.getVCOFQDN() + 
			"]");

	return response;  
  }

//  @WebMethod
//  @WebResult(name="workflowTokenByIdResponse")
//  public WorkflowTokenByIdResponse readWorkflowTokenForId(@WebParam(name="workflowTokenByIdRequest")WorkflowTokenByIdRequest request)
//  {
//	 WorkflowTokenByIdResponse response = new WorkflowTokenByIdResponse();	 
//	 
//	//consumes getWorkflowTokenForId()
//	 
//		Status status = new Status();
//		status.setStatusCode("IS001");
//		status.setStatusDescription("Request processed successfully!!!");
//		
//		response.setStatus(status);
//
//	return response;  
//  }
  
  @WebMethod
  @WebResult(name="runWorkflowResponse")
  public RunWorkflowResponse createExecuteWorkflow(@WebParam(name="runWorkflowRequest")RunWorkflowRequest request)
  {
	RunWorkflowResponse response = new RunWorkflowResponse();
	response.setRequest(request);
	
	//consumes executeWorkflow()
	logger.info("createExecuteWorkflow[solutionName=" + request.getSolutionName() +
			",orderID=" + request.getOrderID() + ",VCO Instance=" + request.getVCOFQDN() + 
			"]");


	return response;  
  }
  
  
  @WebMethod
  @WebResult(name="healthCheckResponse")
  public HealthCheckResponse healthCheckOperation()
  {
	HealthCheckResponse healthCheckResponse = new HealthCheckResponse();
	
	return healthCheckResponse;
  }
  
  @WebMethod
  @WebResult(name="pingResponse")
  public PingResponse pingOperation()
  {
	PingResponse pingResponse = new PingResponse();
	pingResponse.setAppStatus("Service is up and running");
	
	return pingResponse;
  }
  
}
