package net.jpmchase.gti.automation.ibroker.storage.transformer;

import net.jpmchase.gti.automation.ibroker.storage.response.HealthCheckProperty;
import net.jpmchase.gti.automation.ibroker.storage.response.HealthCheckResponse;

import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import org.mule.transformer.AbstractMessageTransformer;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;

public class HealthCheckMessageTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(HealthCheckMessageTransformer.class);
  private static final String IBROKER_DATABASE = "IBrokerDatabase";
  private static final String IBROKER_AUDIT_SERVICE = "iBroker-Audit Service";
  private static final String IBROKER_SECURITY_SERVICE = "iBroker-Security Service";
  private static final String RUNNING = "Running";
  private static final String UNUSED = "Unused";
  
  public HealthCheckResponse transformMessage(MuleMessage message, String outputEncoding)
  	throws TransformerException
  {	
	HealthCheckResponse healthCheckResponse = (HealthCheckResponse)message.getPayload();
	List<HealthCheckProperty> healthChecks = healthCheckResponse.getHealthChecks();
	if (healthChecks == null)
	{
	  healthChecks = new ArrayList<HealthCheckProperty>();
	  healthCheckResponse.setHealthChecks(healthChecks);
	}
	
	logger.debug("Executing healthcheck message transformer...");
	String appVersion = message.getInvocationProperty("app.version");
	
	logger.info("app version=" + appVersion);
	
	addProperty(healthChecks, "app.version", appVersion);	
	addProperty(healthChecks, IBROKER_DATABASE, UNUSED);
	addProperty(healthChecks, IBROKER_AUDIT_SERVICE, UNUSED);
	addProperty(healthChecks, IBROKER_SECURITY_SERVICE, RUNNING);

	  
	return healthCheckResponse;
  }
  
  private void addProperty(List<HealthCheckProperty> healthChecks, String name, String value)
  {
	HealthCheckProperty property = new HealthCheckProperty();
	property.setName(name);
	property.setValue(value);
		
	healthChecks.add(property);		  
  }
}
