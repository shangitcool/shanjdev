package net.jpmchase.gti.automation.ibroker.storage.request;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="workflowTokenStatustRequest")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name="workflowTokenStatustRequest")
public class WorkflowTokenStatustRequest extends WorkflowRequest
{
  @XmlElement(name="workflowTokenIds", required=false)  
  private ArrayList<String> workflowTokenIds;
  
public ArrayList<String> getWorkflowTokenIds() {
	return workflowTokenIds;
}

public void setWorkflowTokenIds(ArrayList<String> workflowTokenIds) {
	this.workflowTokenIds = workflowTokenIds;
}
  
  

}
