package net.jpmchase.gti.automation.ibroker.storage.client.rest.transformer;

import net.jpmchase.gti.automation.ibroker.storage.Status;
import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.WorkflowByNameJSONResponse;
import net.jpmchase.gti.automation.ibroker.storage.response.WorkflowByNameResponse;
import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.NameValuePair;
import net.jpmchase.gti.automation.ibroker.storage.client.rest.response.Link;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

import java.util.List;
import org.apache.log4j.Logger;

public class WorkflowByNameResponseReadTransformer extends AbstractMessageTransformer
{
  private static final Logger logger = Logger.getLogger(WorkflowByNameResponseReadTransformer.class);
	
  @Override
  public Object transformMessage(MuleMessage message, String outputEncoding)
	throws TransformerException	
  {
	WorkflowByNameResponse response = new WorkflowByNameResponse();
	Object src = message.getPayload();
	
	logger.info("WorkflowByNameResponseReadTransformer received payload src=" + src);

	String successCode = message.getInvocationProperty("reserved.success");
	String errorCode = message.getInvocationProperty("reserved.failed");
	String noResultCode = message.getInvocationProperty("reserved.noresult");	

	response.setStatus(getStatus(errorCode)); //assuming not-a-valid request
	if (src instanceof WorkflowByNameJSONResponse)
	{
	  logger.info("WorkflowByNameResponseReadTransformer: payload instance of list=" + src);
	  WorkflowByNameJSONResponse workflowByNameJSONResponse = (WorkflowByNameJSONResponse)src;
  
	  logger.info("WorkflowByNameResponseReadTransformer: checking list empty=" + workflowByNameJSONResponse.getLink().isEmpty());
	  response.setStatus(getStatus(noResultCode)); //assuming no-result from VCO
	  if (!workflowByNameJSONResponse.getLink().isEmpty())
	  {
		
		Link link = (workflowByNameJSONResponse.getLink()).get(0);
		List<NameValuePair> attributes = link.getAttributes();
		for(NameValuePair nameValuePair : attributes){
			if("id".equalsIgnoreCase(nameValuePair.getName())){
				response.setId(nameValuePair.getValue());
			}
			
			if("name".equalsIgnoreCase(nameValuePair.getName())){
				response.setName(nameValuePair.getValue());
			}

			if("description".equalsIgnoreCase(nameValuePair.getName())){
				response.setDescription(nameValuePair.getValue());
			}

		}
		
		response.setStatus(getStatus(successCode));		  
	  }
	}

	return response;
  }

  private Status getStatus(String messageCode)
  {
	String[] messages = messageCode.split(",");
	
	Status status = new Status();
	status.setStatusCode(messages[0]);
	status.setStatusDescription(messages[1]);
	
	return status;
  }
  
}